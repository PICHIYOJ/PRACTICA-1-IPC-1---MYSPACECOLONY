package personaje;

public class Personaje {
    private String nombre;
    private int hp = 100;
    private int mp = 50;
    private int ataque = 10;
    private int defensa = 5;

    public Personaje(String nombre) {
        this.nombre = nombre;
    }

    // Getters
    public String getNombre() { return nombre; }
    public int getHp() { return hp; }
    public int getMp() { return mp; }
    public int getAtaque() { return ataque; }
    public int getDefensa() { return defensa; }

    // Setters
    public void setHp(int hp) { this.hp = hp; }
    public void setMp(int mp) { this.mp = mp; }
    public void setAtaque(int ataque) { this.ataque = ataque; }
    public void setDefensa(int defensa) { this.defensa = defensa; }

    public void mostrarEstado() {
        System.out.println("==================================");
        System.out.println("Nombre: " + nombre);
        System.out.println("HP: " + hp);
        System.out.println("MP: " + mp);
        System.out.println("Ataque: " + ataque);
        System.out.println("Defensa: " + defensa);
    }

    public void modificarHP(int cantidad) {
        hp += cantidad;
        if (hp < 0) hp = 0;
    }

    public void modificarMP(int cantidad) {
        mp += cantidad;
        if (mp < 0) mp = 0;
    }
}