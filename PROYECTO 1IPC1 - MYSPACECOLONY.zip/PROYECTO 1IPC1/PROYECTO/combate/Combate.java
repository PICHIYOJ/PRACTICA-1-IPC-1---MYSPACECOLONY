package combate;

import java.util.Random;
import java.util.Scanner;

import personaje.Personaje;

public class Combate {
    private Personaje jugador;
    private int hpEnemigo;
    private int ataqueEnemigo;
    private int defensaEnemigo;

    public Combate(Personaje jugador) {
        this.jugador = jugador;
        Random rand = new Random();
        this.hpEnemigo = rand.nextInt(jugador.getHp() / 2) + jugador.getHp() / 2;
        this.ataqueEnemigo = rand.nextInt(jugador.getAtaque() / 2) + jugador.getAtaque() / 2;
        this.defensaEnemigo = rand.nextInt(jugador.getDefensa() / 2) + jugador.getDefensa() / 2;
    }

    public void iniciar(Scanner scanner) {
        while (hpEnemigo > 0 && jugador.getHp() > 0) {
            System.out.println("");
            System.out.println("=========================");
            System.out.println("   -----Hora del------   ");
            System.out.println("   ----- COMBATE -----   ");
            System.out.println("=========================");
            System.out.println("HP Enemigo: " + hpEnemigo);
            System.out.println("Tu HP: " + jugador.getHp() + " | MP: " + jugador.getMp());
            System.out.println("1. Atacar\n2. Defender\n3. Curar");

            String accion = scanner.nextLine();

            switch (accion) {
                case "1": // Atacar
                    int daño = jugador.getAtaque() - defensaEnemigo;
                    daño = Math.max(daño, 1);
                    hpEnemigo -= daño;
                    System.out.println("");
                    System.out.println("=======================================================");
                    System.out.println("-------- ¡Gran Golpe!Le has dado su merecido ----------");
                    System.out.println("  Atacaste al enemigo y causaste " + daño + " de daño.   ");
                    System.out.println("=======================================================");
                    break;
                case "2": // Defender
                    if (jugador.getMp() > 0) {
                        jugador.setDefensa(jugador.getDefensa() + 5);
                        jugador.modificarMP(-1);
                        System.out.println("");
                        System.out.println("===================================================");
                        System.out.println("-------------- ¡Defensa Activada! -----------------");
                        System.out.println("   Te defendiste. Defensa aumentada por 2 turnos   ");
                        System.out.println("===================================================");
                    } else {
                        System.out.println("");
                        System.out.println("===================================================");
                        System.out.println("----------------- Lo Lamento :( -------------------");
                        System.out.println("       No tienes suficiente MP para defender       ");
                        System.out.println("===================================================");
                    }
                    break;
                case "3": // Curar
                    if (jugador.getMp() > 0) {
                        int cura = new Random().nextInt(10) + 10;
                        jugador.modificarHP(cura);
                        jugador.modificarMP(-1);
                        System.out.println("");
                        System.out.println("=====================================================");
                        System.out.println("----------------   Curaaa Activada   ----------------");
                        System.out.println("         Te curaste " + cura + " puntos de vida        ");
                        System.out.println("=====================================================");
                    } else {
                        System.out.println("No tienes suficiente MP para curarte.");
                    }
                    break;
                default:
                    System.out.println("ERROR: Acción no válida.");
            }

            // Ataque del enemigo
            if (hpEnemigo > 0) {
                int daño = ataqueEnemigo - jugador.getDefensa();
                daño = Math.max(daño, 1);
                jugador.modificarHP(-daño);
                System.out.println("");
                System.out.println("===================================================");
                System.out.println("----------------- Te han Atacado ------------------");
                System.out.println("   El enemigo te atacó y causó " + daño + " de daño   ");
                System.out.println("===================================================");
            }
        }

        if (jugador.getHp() > 0) {
            System.out.println("");
            System.out.println("===========================================");
            System.out.println("          ----- ¡VAMOOOS! -----            ");
            System.out.println("----------- Que Gran Batalla --------------");
            System.out.println("          ¡Ganaste el combate!             ");
            System.out.println("        Sigue en busca del Tesoro          ");
            System.out.println("===========================================");
        } else {
            System.out.println("");
            System.out.println("===========================================");
            System.out.println("          ----- ¡Oh NOO! -----            ");
            System.out.println("         ¡Perdiste el combate! :(         ");
            System.out.println("===========================================");
        }
    }
}