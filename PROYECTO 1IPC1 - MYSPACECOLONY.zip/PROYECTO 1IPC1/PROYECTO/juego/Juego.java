// Juego.java
// Juego.java
package juego;

import mapa.CasillaMuro;
import mapa.CasillaTesoro;
import mapa.CasillaEnemigo;
import mapa.MapaPredefinido1;
import mapa.MapaPredefinido2;
import mapa.MapaPersonalizado;
import mapa.Mapa;
import personaje.Personaje;
import utilidades.ArchivoManager;
import utilidades.Reporteador;
import java.util.Scanner;


public class Juego {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Personaje jugador = null;
        Mapa mapa = null;

        boolean salir = false;
        while (!salir) {
            System.out.println("");
            System.out.println("------------------------------");
            System.out.println("        Code'n Bugs");
            System.out.println("==============================");
            System.out.println(" BIENVENIDO A TREASURE HUNTER");
            System.out.println("==============================");
            System.out.println("");
                    
            System.out.println("1. Explicación del Juego");
            System.out.println("2. Nueva Partida");
            System.out.println("3. Cargar Personaje");
            System.out.println("4. Ver Reportes");
            System.out.println("5. Salir");
            System.out.println("------------------------------");
            System.out.print("Selecciona una opción: ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":
                    mostrarExplicacion(scanner);
                    continue;
                case "2":
                    System.out.println("");
                    System.out.println("======================================");
                    System.out.println("           CREA A TU PERSONAJE          ");
                    System.out.println("======================================");
                    System.out.print("Ingresa el nombre de tu Aventurero: ");
                    String nombre = scanner.nextLine();
                    jugador = new Personaje(nombre);
                    System.out.println("");

                    System.out.println("");
                    System.out.println("======================================");
                    System.out.println("     Elige un mapa para tu aventura  ");
                    System.out.println("======================================");
                    System.out.println("1. Mapa Predefinido 1");
                    System.out.println("2. Mapa Predefinido 2");
                    System.out.println("3. Crear un Mapa Nuevo");
                    System.out.print("Selecciona una opción: ");
                    String opcionMapa = scanner.nextLine();

                    // Selección del mapa
                    switch (opcionMapa) {
                        case "1":
                            mapa = new MapaPredefinido1();
                            break;
                        case "2":
                            mapa = new MapaPredefinido2();
                            break;
                        case "3":
                            System.out.println("Ingresa el número de filas del mapa: ");
                            int filas = Integer.parseInt(scanner.nextLine());
                            System.out.println("Ingresa el número de columnas del mapa: ");
                            int columnas = Integer.parseInt(scanner.nextLine());
                            mapa = new MapaPersonalizado(filas, columnas);
                            break;
                        default:
                            mapa = new MapaPredefinido1();
                            break;
                    }
                    break;
                case "3":
                    jugador = ArchivoManager.cargarPersonaje();
                    if (jugador == null) {
                        System.out.println("");
                        System.out.println("==================================");
                        System.out.println("------------- ¡UPS! --------------");
                        System.out.println("  No se pudo cargar el personaje  ");
                        System.out.println("==================================");
                        continue;
                    }
                    break;
                case "4":
                    Reporteador.mostrarGanadoresPorMovimientos();
                    continue;
                case "5":
                    System.out.println("");
                    System.out.println("======================================");
                    System.out.println("-------- GRACIAS POR JUGAR :D --------");
                    System.out.println("          ¡Hasta la próxima!          ");
                    System.out.println("======================================");
                    System.out.println("             Code'n Bugs              ");
                    System.out.println("--------------------------------------");
                    salir = true;
                    continue;
                default:
                    System.out.println("Opción no válida. Intenta de Nuevo");
                    continue;
            }

            // Si se ha elegido un mapa y un personaje, empezar el juego
            if (mapa != null && jugador != null) {
                jugar(mapa, jugador, scanner);  // Pasamos al método de juego
            }
        }

        scanner.close();
    }

    public static void jugar(Mapa mapa, Personaje jugador, Scanner scanner) {
        int jugadorFila = 0;
        int jugadorColumna = 0;

        int movimientos = 0;
        int batallasGanadas = 0;
        boolean juegoTerminado = false;

        String comando;

        do {
            System.out.println("");
            System.out.println("\n--- ESTATUS DEL AVENTURERO ---");
            jugador.mostrarEstado();
            System.out.println("--------------------------------");
            System.out.println("       --- MAPA ACTUAL ---      ");
            System.out.println("=================================");
            mapa.mostrarMapa(jugadorFila, jugadorColumna);
            System.out.println("=================================");

            System.out.print("Mover (w/a/s/d), guardar (g), ver reportes (r) o salir (x): ");
            comando = scanner.nextLine();

            switch (comando) {
                case "w":
                    if (jugadorFila > 0 && !(mapa.getCasilla(jugadorFila - 1, jugadorColumna) instanceof CasillaMuro)) {
                        jugadorFila--;
                        movimientos++;
                    } else {
                        System.out.println("¡Hay un muro! No puedes pasar.");
                    }
                    break;
                case "s":
                    if (jugadorFila < mapa.getFilas() - 1 && !(mapa.getCasilla(jugadorFila + 1, jugadorColumna) instanceof CasillaMuro)) {
                        jugadorFila++;
                        movimientos++;
                    } else {
                        System.out.println("¡Hay un muro! No puedes pasar.");
                    }
                    break;
                case "a":
                    if (jugadorColumna > 0 && !(mapa.getCasilla(jugadorFila, jugadorColumna - 1) instanceof CasillaMuro)) {
                        jugadorColumna--;
                        movimientos++;
                    } else {
                        System.out.println("¡Hay un muro! No puedes pasar.");
                    }
                    break;
                case "d":
                    if (jugadorColumna < mapa.getColumnas() - 1 && !(mapa.getCasilla(jugadorFila, jugadorColumna + 1) instanceof CasillaMuro)) {
                        jugadorColumna++;
                        movimientos++;
                    } else {
                        System.out.println("¡Hay un muro! No puedes pasar.");
                    }
                    break;
                case "g":
                    ArchivoManager.guardarPersonaje(jugador);
                    break;
                case "r":
                    Reporteador.mostrarGanadoresPorMovimientos();
                    break;
                case "x":
                    System.out.println("Saliendo del juego...");
                    juegoTerminado = true;
                    break;
                default:
                    System.out.println("Comando no válido.");
            }

            if (!comando.equals("x")) {
                if (mapa.getCasilla(jugadorFila, jugadorColumna) instanceof CasillaTesoro) {
                    Reporteador.agregarGanador(jugador.getNombre(), movimientos, batallasGanadas);
                    mapa.activarCasilla(jugadorFila, jugadorColumna, jugador);
                    juegoTerminado = true;
                } else if (mapa.getCasilla(jugadorFila, jugadorColumna) instanceof CasillaEnemigo) {
                    batallasGanadas++;
                    mapa.activarCasilla(jugadorFila, jugadorColumna, jugador);
                } else {
                    mapa.activarCasilla(jugadorFila, jugadorColumna, jugador);
                }
            }

        } while (!juegoTerminado);
    }

    public static void mostrarExplicacion(Scanner scanner) {
        System.out.println("");
        System.out.println("================================================================");
        System.out.println("--------------------- Explicacion del Juego --------------------");
        System.out.println("================================================================");
        System.out.println("  - Cómo Jugar:                                     ");
        System.out.println("Crea a tu Aventurero y tu mapa por explorar, tu ");
        System.out.println("personaje tiene HP, MP, Ataque y Defensa.");
        System.out.println("");
        System.out.println("  - Mueve a tu Aventurero con las teclas w/a/s/d.");
        System.out.println("   w(ARRIBA), s(ABAJO), a(DERECHA), d(IZQUIERDA)");
        System.out.println("");
        System.out.println("  - Interactúa con el mapa:                         ");
        System.out.println("Casillas con Muro(M)/Bloquean el camino");
        System.out.println("Casillas con Enemigos(X)/Inician combates");
        System.out.println("Casillas con Enería(E)/recupera HP/MP,Teletransporte");
        System.out.println("Casillas con Trampa(t)/Te hacen daño");
        System.out.println("Casillas con Teletransporte(T)/Te lleva a una ubicación aleatoria");
        System.out.println("Casilla con Tesoro($)/Te hace:");
        System.out.println("------------------------ GANAR EL JUEGO -------------------------");
        System.out.println("");
        System.out.println("  - En Combate:");
        System.out.println("Elige entre Atacar, Defender o Curar usando tus MP Y HP");
        System.out.println("Administra tus MP, HP, Evita trampas, muros en tu camino y GANA");
        System.out.println("--------------------- ¡DISFRUTA DEL JUEGO! ----------------------");
        System.out.println("");
        System.out.println("=================================================================");
        System.out.println("        -- Presiona ENTER para volver al menú y jugar --         ");
        System.out.println("");
      
        scanner.nextLine();
    }
}
