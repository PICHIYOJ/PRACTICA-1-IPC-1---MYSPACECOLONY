package utilidades;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import personaje.Personaje;

public class ArchivoManager {

    public static void guardarPersonaje(Personaje personaje) {
        try (FileWriter fw = new FileWriter("personaje.txt");
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(personaje.getNombre() + "," +
                     personaje.getHp() + "," +
                     personaje.getMp() + "," +
                     personaje.getAtaque() + "," +
                     personaje.getDefensa());
            bw.newLine();

            bw.flush();
            System.out.println("");
            System.out.println("------------ LISTO -------------");
            System.out.println("Personaje GUARDADO exitosamente.");
            System.out.println("--------------------------------");
            System.out.println("");
            System.out.flush();

        } catch (IOException e) {
            System.out.println("");
            System.out.println("------------- ¡OH! -------------");
            System.out.println("EROROR: al guardar el personaje.");
            System.out.println("");
            System.out.flush();
        }
    }

    public static Personaje cargarPersonaje() {
        try (BufferedReader br = new BufferedReader(new FileReader("personaje.txt"))) {
            String linea = br.readLine();
            if (linea != null) {
                String[] datos = linea.split(",");
                Personaje personaje = new Personaje(datos[0]);
                personaje.setHp(Integer.parseInt(datos[1]));
                personaje.setMp(Integer.parseInt(datos[2]));
                personaje.setAtaque(Integer.parseInt(datos[3]));
                personaje.setDefensa(Integer.parseInt(datos[4]));
                System.out.println("");
                System.out.println("------------ LISTO -------------");
                System.out.println("Personaje CARGADO exitosamente.");
                System.out.println("--------------------------------");
                System.out.println("");
                return personaje;
            }
        } catch (IOException e) {
            System.out.println("");
            System.out.println("------------- ¡OH! -------------");
            System.out.println("ERROR: al cargar el personaje.");
            System.out.println("");
        }

        return null;
    }
}
