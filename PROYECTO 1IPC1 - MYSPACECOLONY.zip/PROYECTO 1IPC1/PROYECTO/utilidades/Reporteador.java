package utilidades;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Reporteador {

    // Método para agregar un ganador al archivo
    public static void agregarGanador(String nombre, int movimientos, int batallasGanadas) {
        try (FileWriter fw = new FileWriter("ganadores.txt", true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(nombre + "," + movimientos + "," + batallasGanadas);
            bw.newLine();

        } catch (IOException e) {
            System.out.println("ERROR: al registrar ganador.");
        }
    }

    // Método para mostrar los ganadores ordenados por movimientos
    public static void mostrarGanadoresPorMovimientos() {
        String[][] lista = leerArchivo("ganadores.txt");

        // Ordenar el arreglo basado en el número de movimientos (columna 1)
        for (int i = 0; i < lista.length - 1; i++) {
            for (int j = i + 1; j < lista.length; j++) {
                if (Integer.parseInt(lista[i][1]) < Integer.parseInt(lista[j][1])) {
                    // Intercambiar los elementos si están en el orden incorrecto
                    String[] temp = lista[i];
                    lista[i] = lista[j];
                    lista[j] = temp;
                }
            }
        }

        System.out.println("Ganadores ordenados por movimientos:");
        for (String[] datos : lista) {
            System.out.println("Jugador: " + datos[0] + " | Movimientos: " + datos[1] + " | Batallas ganadas: " + datos[2]);
        }
    }

    // Método para leer el archivo y devolver los datos como un arreglo
    private static String[][] leerArchivo(String nombreArchivo) {
        String[][] lista = new String[100][3];  // Establecemos un tamaño máximo para el arreglo
        int index = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                lista[index] = datos;
                index++;
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer " + nombreArchivo);
        }

        String[][] listaFinal = new String[index][3];
        System.arraycopy(lista, 0, listaFinal, 0, index);

        return listaFinal;
    }
}
