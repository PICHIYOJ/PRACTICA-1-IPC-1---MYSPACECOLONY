package mapa;

import java.util.Scanner;

import combate.Combate;
import personaje.Personaje;

public class CasillaEnemigo extends Casilla {
    public CasillaEnemigo() {
        simbolo = 'X';
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("");
        System.out.println("============================");
        System.out.println(" --- Cuidado Aventurero --- ");
        System.out.println("    ¡Un enemigo aparece!   ");
        System.out.println("============================");
        Scanner scanner = new Scanner(System.in);
        Combate combate = new Combate(jugador);
        combate.iniciar(scanner);
    }
}