package mapa;

import personaje.Personaje;

public abstract class Mapa {
    protected Casilla[][] mapa;
    protected int filas;
    protected int columnas;

    public Mapa(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        mapa = new Casilla[filas][columnas];  
        inicializar(); 
    }

    
    public abstract void inicializar();

   
    public int getFilas() {
        return filas;
    }

    public int getColumnas() {
        return columnas;
    }

   
    public void mostrarMapa(int jugadorFila, int jugadorCol) {
        System.out.println();
        for (int i = 0; i < filas; i++) {
            System.out.print("|"); // Borde izquierdo
            for (int j = 0; j < columnas; j++) {
                if (i == jugadorFila && j == jugadorCol) {
                    System.out.print(" * |"); // Representa al jugador en el mapa
                } else {
                    System.out.print(" " + mapa[i][j].getSimbolo() + " |");  // Mostrar el símbolo de cada casilla
                }
            }
            System.out.println();
        }
        System.out.println();
    }

   
    public void activarCasilla(int fila, int col, Personaje jugador) {
        mapa[fila][col].activar(jugador);  
    }

    
    public Casilla getCasilla(int fila, int columnas) {
        return mapa[fila][columnas];
    }
}

