package mapa;

import personaje.Personaje;

public class CasillaNormal extends Casilla {

    public CasillaNormal() {
        simbolo = 'N';
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("");
        System.out.println("==============================");
        System.out.println("    - Vas por Buen Camino -   ");
        System.out.println("Has pisado una casilla normal ");
        System.out.println("==============================");
    }
}