// CasillaEnergia.java
package mapa;

import personaje.Personaje;

public class CasillaEnergia extends Casilla {
    private int energia;
    private boolean recuperaHP; // true = HP, false = MP

    // Constructor con parámetros
    public CasillaEnergia(int energia, boolean recuperaHP) {
        this.energia = energia;
        this.recuperaHP = recuperaHP;
        simbolo = 'E';  // Símbolo de la casilla de energía
    }

    // Constructor sin parámetros (con valores predeterminados)
    public CasillaEnergia() {
        this.energia = 20;  // Valor predeterminado para energía
        this.recuperaHP = true;  // Valor predeterminado para HP
        simbolo = 'E';  // Símbolo de la casilla de energía
    }

    @Override
    public void activar(Personaje jugador) {
        if (recuperaHP) {
            jugador.modificarHP(energia);  // Recupera HP
            System.out.println("");
            System.out.println("==================================================================");
            System.out.println("   -------------- Justo Lo que Necesitabas :) -----------------   ");
            System.out.println("   Encontraste energía. Recuperaste " + energia + " puntos de vida  ");
            System.out.println("==================================================================");
        } else {
            jugador.modificarMP(energia);  // Recupera MP
            System.out.println("");
            System.out.println("==================================================================");
            System.out.println("------------------------ ¡Uff Buena Esa! -------------------------");
            System.out.println("  Encontraste energía. Recuperaste " + energia + " puntos de maná   ");
            System.out.println("==================================================================");
        }
    }
}
