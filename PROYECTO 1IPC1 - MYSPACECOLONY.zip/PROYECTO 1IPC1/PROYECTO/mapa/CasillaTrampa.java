// CasillaTrampa.java
package mapa;

import personaje.Personaje;

public class CasillaTrampa extends Casilla {
    private int daño;
    private boolean afectaHP; // true = HP, false = MP

    // Constructor con parámetros
    public CasillaTrampa(int daño, boolean afectaHP) {
        this.daño = daño;
        this.afectaHP = afectaHP;
        simbolo = 't';  // Símbolo de la trampa
    }

    @Override
    public void activar(Personaje jugador) {
        if (afectaHP) {
            jugador.modificarHP(-daño); // Restar daño a HP
            System.out.println("");
            System.out.println("==============================================");
            System.out.println("               -- MALA SUERTE --             ");
            System.out.println(" ¡Trampa! Perdiste " + daño + " puntos de vida.");
            System.out.println("===============================================");
        } else {
            jugador.modificarMP(-daño); // Restar daño a MP
            System.out.println("");
            System.out.println("==============================================");
            System.out.println("               -- MALA SUERTE --             ");
            System.out.println("¡Trampa! Perdiste " + daño + " puntos de maná.");
            System.out.println("===============================================");
        }
    }
}

