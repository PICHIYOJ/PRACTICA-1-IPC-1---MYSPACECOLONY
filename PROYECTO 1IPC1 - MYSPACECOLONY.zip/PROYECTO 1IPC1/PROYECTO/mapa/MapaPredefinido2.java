// MapaPredefinido2.java
package mapa;

import java.util.Random;

public class MapaPredefinido2 extends Mapa {
    private boolean tesoroColocado = false;  // Flag para verificar si el tesoro ya fue colocado

    public MapaPredefinido2() {
        super(10, 10);  // Usamos valores predeterminados para filas y columnas (por ejemplo, 10x10)
        inicializar();  // Llamamos al método de inicialización
    }

    @Override
    public void inicializar() {
        Random rand = new Random();

        // Inicializar el mapa con casillas aleatorias
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int probabilidad = rand.nextInt(100); // Probabilidad aleatoria para asignar un tipo de casilla

                // Probabilidades de aparición de cada tipo de casilla
                if (probabilidad < 10) {
                    mapa[i][j] = new CasillaMuro(); // 10% Muro
                } else if (probabilidad < 20) {
                    mapa[i][j] = new CasillaEnemigo(); // 10% Enemigo
                } else if (probabilidad < 30) {
                    int energia = rand.nextInt(20) + 10;  // Generar un valor de energía aleatorio entre 10 y 30
                    boolean recuperaHP = rand.nextBoolean(); // Aleatorio entre HP o MP
                    mapa[i][j] = new CasillaEnergia(energia, recuperaHP); // 10% Energía con parámetros
                } else if (probabilidad < 40) {
                    int daño = rand.nextInt(20) + 5;  // Daño entre 5 y 25
                    boolean afectaHP = rand.nextBoolean(); // Aleatorio entre HP o MP
                    mapa[i][j] = new CasillaTrampa(daño, afectaHP); // 10% Trampa
                } else if (probabilidad < 50) {
                    mapa[i][j] = new CasillaPista(); // 10% Pista
                } else if (probabilidad < 60) {
                    mapa[i][j] = new CasillaTeletransporte(); // 10% Teletransporte
                } else if (probabilidad < 70) {
                    mapa[i][j] = new CasillaTesoro(); // 10% Tesoro
                } else {
                    mapa[i][j] = new CasillaNormal(); // Resto: Casillas normales
                }
            }
        }

        // Colocar el tesoro solo una vez en una posición aleatoria
        if (!tesoroColocado) {
            int filaTesoro = rand.nextInt(filas);
            int colTesoro = rand.nextInt(columnas);
            mapa[filaTesoro][colTesoro] = new CasillaTesoro();  // Coloca el tesoro en una posición aleatoria
            tesoroColocado = true;  // Aseguramos que el tesoro no se coloque de nuevo
        }
    }
}
