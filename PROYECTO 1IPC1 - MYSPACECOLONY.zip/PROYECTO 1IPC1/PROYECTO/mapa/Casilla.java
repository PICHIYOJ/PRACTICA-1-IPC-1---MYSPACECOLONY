package mapa;

import personaje.Personaje;

public abstract class Casilla {
    protected char simbolo;

    public abstract void activar(Personaje jugador);

    public char getSimbolo() {
        return simbolo;
    }
}
