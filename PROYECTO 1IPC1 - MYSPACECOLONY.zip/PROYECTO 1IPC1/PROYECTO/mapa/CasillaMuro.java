package mapa;

import personaje.Personaje;

public class CasillaMuro extends Casilla {

    public CasillaMuro() {
        simbolo = 'M';
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("");
        System.out.println("=====================================================");
        System.out.println("                   --- PUM ---                      ");
        System.out.println("¡Has chocado contra un muro! No podés pasar por aquí.");
        System.out.println("=====================================================");
    }
}