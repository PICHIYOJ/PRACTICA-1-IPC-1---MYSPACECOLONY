// CasillaTeletransporte.java
package mapa;

import java.util.Random;

import personaje.Personaje;

public class CasillaTeletransporte extends Casilla {
    private int destinoFila;
    private int destinoColumna;
    private boolean aleatorio;

    public CasillaTeletransporte(boolean aleatorio, int fila, int columna) {
        this.aleatorio = aleatorio;
        this.destinoFila = fila;
        this.destinoColumna = columna;
        simbolo = 'T';
    }
    public CasillaTeletransporte() {
        this.aleatorio = true;  
        this.destinoFila = 0;   
        this.destinoColumna = 0;  
        simbolo = 'T';  // Símbolo de la casilla de teletransporte
    }

    public int[] obtenerDestino(int maxFilas, int maxColumnas) {
        if (aleatorio) {
            Random rand = new Random();
            return new int[]{rand.nextInt(maxFilas), rand.nextInt(maxColumnas)};
        } else {
            return new int[]{destinoFila, destinoColumna};
        }
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("");
        System.out.println("==================================================");
        System.out.println("¡Teletransportado! ¡Suerte con tu nueva ubicación!");
        System.out.println("==================================================");
    }
}

