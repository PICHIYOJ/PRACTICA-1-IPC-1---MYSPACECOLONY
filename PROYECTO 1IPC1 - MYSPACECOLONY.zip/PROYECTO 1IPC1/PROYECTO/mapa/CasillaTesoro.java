package mapa;

import personaje.Personaje;

public class CasillaTesoro extends Casilla {

    public CasillaTesoro() {
        simbolo = '$'; 
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("");
        System.out.println("  ¡Felicidades " + jugador.getNombre() + "! ¡Has encontrado el tesoro y ganado el juego!");
        System.out.println("======================================================================================");
        System.out.println("             -------------------- V I C T O  R I A ---------------------              ");
        System.out.println("======================================================================================");
}
}
