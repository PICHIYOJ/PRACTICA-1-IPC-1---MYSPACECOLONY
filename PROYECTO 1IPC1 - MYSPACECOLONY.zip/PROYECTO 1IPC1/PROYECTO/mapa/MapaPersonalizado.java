// MapaPersonalizado.java
package mapa;

import java.util.Random;

public class MapaPersonalizado extends Mapa {
    public MapaPersonalizado(int filas, int columnas) {
        super(filas, columnas);  
        inicializar(); 
    }

    @Override
    public void inicializar() {
        Random rand = new Random();

        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int probabilidad = rand.nextInt(100); 

                // Probabilidades de aparición de cada tipo de casilla
                if (probabilidad < 10) {
                    mapa[i][j] = new CasillaMuro(); // 10% Muro
                } else if (probabilidad < 20) {
                    mapa[i][j] = new CasillaEnemigo(); // 10% Enemigo
                } else if (probabilidad < 30) {
                    int energia = rand.nextInt(20) + 10;  // Generar un valor de energía aleatorio entre 10 y 30
                    boolean recuperaHP = rand.nextBoolean(); // Aleatorio entre HP o MP
                    mapa[i][j] = new CasillaEnergia(energia, recuperaHP); // 10% Energía con parámetros
                } else if (probabilidad < 40) {
                    int daño = rand.nextInt(20) + 5;  // Daño entre 5 y 25
                    boolean afectaHP = rand.nextBoolean(); // Aleatorio entre HP o MP
                    mapa[i][j] = new CasillaTrampa(daño, afectaHP); // 10% Trampa
                } else if (probabilidad < 50) {
                    mapa[i][j] = new CasillaPista(); // 10% Pista
                } else if (probabilidad < 60) {
                    // Crear un teletransporte con valores aleatorios
                    boolean aleatorio = rand.nextBoolean();  // Aleatorio si es aleatorio o no
                    int filaDestino = rand.nextInt(filas);   // Fila aleatoria de destino
                    int colDestino = rand.nextInt(columnas); // Columna aleatoria de destino
                    mapa[i][j] = new CasillaTeletransporte(aleatorio, filaDestino, colDestino); // 10% Teletransporte
                } else if (probabilidad < 70) {
                    mapa[i][j] = new CasillaTesoro(); // 10% Tesoro
                } else {
                    mapa[i][j] = new CasillaNormal(); // Resto: Casillas normales
                }
            }
        }
    }
}
