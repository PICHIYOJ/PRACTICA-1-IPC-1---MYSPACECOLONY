// CasillaPista.java
package mapa;

import personaje.Personaje;

public class CasillaPista extends Casilla {
    private String pista;

    // Constructor sin parámetros
    public CasillaPista() {
        pista = "¡Estás cerca del tesoro!";  // Pista predeterminada
        simbolo = 'P';  // Símbolo de la pista
    }

    // Constructor con parámetro
    public CasillaPista(String pista) {
        this.pista = pista;
        simbolo = 'P';  // Símbolo de la pista
    }

    @Override
    public void activar(Personaje jugador) {
        System.out.println("Pista: " + pista);
    }
}
