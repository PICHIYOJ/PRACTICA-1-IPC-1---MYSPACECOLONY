package com.myspacecolony.core;

import com.myspacecolony.ds.ArrayQueue;
import com.myspacecolony.ds.DynamicArray;
import com.myspacecolony.ranch.Parcel;

public class Grid implements java.io.Serializable {
    private Cell[][] cells;
    private int rows, cols;

    private final DynamicArray<Parcel> parcels = new DynamicArray<>();
    private int nextParcelId = 1;

    public static final int EXPANSION_COST_PER_CELL = 50; // precio por celda nueva

    public Grid(int rows,int cols){ this.rows=rows; this.cols=cols; cells=new Cell[rows][cols]; generate(); }

    private void generate(){
        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++){
                cells[r][c] = new Cell(r,c, randomTerrain());
            }
        }
    }

    private TerrainType randomTerrain(){
        double p = Math.random();
        return (p<0.40)? TerrainType.FERTILE : (p<0.75? TerrainType.AQUIFER : TerrainType.ARID);
    }

    public int getRows(){ return rows; }
    public int getCols(){ return cols; }
    public Cell get(int r,int c){ return cells[r][c]; }

    public DynamicArray<Cell> allCells(){
        DynamicArray<Cell> out = new DynamicArray<>();
        for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) out.add(cells[r][c]);
        return out;
    }

    // ======= FASE 2: parcelas =======
    public Parcel getParcelByCell(int r,int c){
        int id = cells[r][c].getParcelId();
        if(id<0) return null;
        for(int i=0;i<parcels.size();i++) if(parcels.get(i).id==id) return parcels.get(i);
        return null;
    }

    public Parcel createParcelFrom(int sr,int sc,int count) throws com.myspacecolony.core.Exceptions.InvalidActionException {
        if(!in(sr,sc)) throw new com.myspacecolony.core.Exceptions.InvalidActionException("Fuera de rango");
        if(cells[sr][sc].getTerrain()!=TerrainType.FERTILE) throw new com.myspacecolony.core.Exceptions.InvalidActionException("Debe iniciar en fértil");
        if(cells[sr][sc].getParcelId()>=0) throw new com.myspacecolony.core.Exceptions.InvalidActionException("Celda ya en parcela");

        Parcel p = new Parcel(nextParcelId++);
        parcels.add(p);
        ArrayQueue<int[]> q = new ArrayQueue<>();
        q.enqueue(new int[]{sr,sc});
        int taken=0;
        boolean[][] vis = new boolean[rows][cols];
        while(!q.isEmpty() && taken<count){
            int[] v = q.dequeue();
            int r=v[0], c=v[1];
            if(!in(r,c) || vis[r][c]) continue; vis[r][c]=true;
            Cell cl = cells[r][c];
            if(cl.getTerrain()==TerrainType.FERTILE && cl.getParcelId()<0 && cl.getCrop()==null && cl.getExtractor()==null){
                cl.setParcelId(p.id);
                p.cells.add(cl);
                taken++;
            }
            if(in(r-1,c)) q.enqueue(new int[]{r-1,c});
            if(in(r+1,c)) q.enqueue(new int[]{r+1,c});
            if(in(r,c-1)) q.enqueue(new int[]{r,c-1});
            if(in(r,c+1)) q.enqueue(new int[]{r,c+1});
        }
        if(p.cells.size()==0) throw new com.myspacecolony.core.Exceptions.InvalidActionException("No hay fértiles contiguas libres");
        return p;
    }

    public void deleteParcelIfEmpty(int r,int c) throws com.myspacecolony.core.Exceptions.InvalidActionException {
        Parcel p = getParcelByCell(r,c);
        if(p==null) throw new com.myspacecolony.core.Exceptions.InvalidActionException("No hay parcela aquí");
        if(!p.emptyOfLiving()) throw new com.myspacecolony.core.Exceptions.InvalidActionException("Parcela con seres activos o cadáveres");
        for(int i=0;i<p.cells.size();i++) p.cells.get(i).setParcelId(-1);
        for(int i=0;i<parcels.size();i++) if(parcels.get(i).id==p.id){ parcels.removeAt(i); break; }
    }

    private boolean in(int r,int c){ return r>=0 && r<rows && c>=0 && c<cols; }

    // ==== APIs cultivo/extractor ====
    public void placeCrop(int r,int c, com.myspacecolony.farming.Crop crop)
            throws com.myspacecolony.core.Exceptions.InvalidActionException {
        Cell cl = cells[r][c];
        if(cl.getTerrain()!=TerrainType.FERTILE)
            throw new com.myspacecolony.core.Exceptions.InvalidActionException("Se siembra solo en fértil");
        if(cl.getCrop()!=null || cl.getExtractor()!=null)
            throw new com.myspacecolony.core.Exceptions.InvalidActionException("Celda ocupada");
        crop.setFertilityFactor(cl.getFertility()); // Fase 2.5
        cl.setCrop(crop);
    }
    public void placeExtractor(int r,int c, com.myspacecolony.industry.Extractor ex)
            throws com.myspacecolony.core.Exceptions.InvalidActionException {
        Cell cl=cells[r][c];
        if(cl.getTerrain()!=TerrainType.AQUIFER)
            throw new com.myspacecolony.core.Exceptions.InvalidActionException("Extractor solo en acuífero");
        if(cl.getCrop()!=null || cl.getExtractor()!=null)
            throw new com.myspacecolony.core.Exceptions.InvalidActionException("Celda ocupada");
        cl.setExtractor(ex);
    }
    public void cleanCell(int r,int c){ cells[r][c].clearAll(); }

    // ======= FASE 3: Expansión =======
    public void expandRows(int addRows){
        if(addRows<=0) return;
        int newRows = rows + addRows;
        Cell[][] newCells = new Cell[newRows][cols];
        for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) newCells[r][c] = cells[r][c];
        // generar filas nuevas al final
        for(int r=rows; r<newRows; r++){
            for(int c=0;c<cols;c++){
                newCells[r][c] = new Cell(r,c, randomTerrain());
            }
        }
        cells = newCells;
        rows = newRows;
    }

    public void expandCols(int addCols){
        if(addCols<=0) return;
        int newCols = cols + addCols;
        Cell[][] newCells = new Cell[rows][newCols];
        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++) newCells[r][c] = cells[r][c];
            for(int c=cols;c<newCols;c++){
                newCells[r][c] = new Cell(r,c, randomTerrain());
            }
        }
        cells = newCells;
        cols = newCols;
    }
}
