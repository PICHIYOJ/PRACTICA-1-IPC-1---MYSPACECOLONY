package com.myspacecolony.farming;


import com.myspacecolony.core.MissionData;


public interface Harvestable {
boolean isReady();
void harvest(MissionData mission);
}