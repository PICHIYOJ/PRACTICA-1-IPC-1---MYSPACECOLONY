package com.myspacecolony.core;

import java.awt.Toolkit;

public class Sound {
    public static volatile boolean enabled = true;

    public static void success(){
        if(!enabled) return;
        Toolkit.getDefaultToolkit().beep();
    }
    public static void error(){
        if(!enabled) return;
        // doble beep simple
        Toolkit.getDefaultToolkit().beep();
        try { Thread.sleep(100); } catch (InterruptedException ignored) {}
        Toolkit.getDefaultToolkit().beep();
    }
    public static void event(){
        if(!enabled) return;
        Toolkit.getDefaultToolkit().beep();
    }
}
