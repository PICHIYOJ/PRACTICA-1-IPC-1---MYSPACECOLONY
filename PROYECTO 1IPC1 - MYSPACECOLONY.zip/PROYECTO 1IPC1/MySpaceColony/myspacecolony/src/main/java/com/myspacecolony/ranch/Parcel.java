package com.myspacecolony.ranch;

import com.myspacecolony.core.Cell;
import com.myspacecolony.core.MissionData;
import com.myspacecolony.ds.DynamicArray;

public class Parcel implements java.io.Serializable{
    public final int id;
    public final DynamicArray<Cell> cells = new DynamicArray<>();
    private final DynamicArray<Creature> creatures = new DynamicArray<>();
    private SpeciesKind kind = null;
    private double used = 0.0;
    private int corpses = 0;

    public Parcel(int id){ this.id = id; }

    public double capacity(){ return cells.size(); } // 1 celda = 1.0 unidad
    public double free(){ return capacity() - used; }

    public boolean addCreature(Creature c){
        if(!c.isAlive()) return false;
        if(kind==null) kind = (c instanceof AlienChicken)? SpeciesKind.OMNIVORE : SpeciesKind.HERBIVORE;
        if(kind!=((c instanceof AlienChicken)? SpeciesKind.OMNIVORE : SpeciesKind.HERBIVORE)) return false;
        if(free() < c.spaceRequired()) return false;
        creatures.add(c);
        used += c.spaceRequired();
        return true;
    }

    public int collectAll(MissionData m){
        int sum=0;
        for(int i=0;i<creatures.size();i++){
            Creature cr = creatures.get(i);
            sum += cr.collect(m);
        }
        return sum;
    }

    public int slaughterAll(MissionData m){
        int cnt=0;
        for(int i=0;i<creatures.size();i++){
            Creature cr = creatures.get(i);
            if(cr.isAlive()){ cr.slaughter(m); cnt++; corpses++; used -= 0; /* ocupa hasta limpiar */ }
        }
        return cnt;
    }

    public void tick(long dt, MissionData m){
        for(int i=0;i<creatures.size();i++){
            Creature cr = creatures.get(i);
            boolean wasAlive = cr.isAlive();
            cr.tick(dt,m);
            if(wasAlive && !cr.isAlive()){ corpses++; }
        }
    }

    public boolean emptyOfLiving(){
        for(int i=0;i<creatures.size();i++) if(creatures.get(i).isAlive()) return false;
        return corpses==0;
    }

    public int corpses(){ return corpses; }
    public void cleanCorpses(){ corpses = 0; }
}
