package com.myspacecolony.ui;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.myspacecolony.core.Cell;
import com.myspacecolony.core.Exceptions.NotEnoughCreditsException;
import com.myspacecolony.core.Grid;
import com.myspacecolony.core.MissionData;
import com.myspacecolony.core.MissionStats;
import com.myspacecolony.core.Sound;
import com.myspacecolony.core.TerrainType;
import com.myspacecolony.farming.AppleTreeCrop;
import com.myspacecolony.farming.Crop;
import com.myspacecolony.farming.MaizeCrop;
import com.myspacecolony.industry.Extractor;
import com.myspacecolony.items.Product;
import com.myspacecolony.market.Market;
import com.myspacecolony.ranch.AlienChicken;
import com.myspacecolony.ranch.CosmicCow;
import com.myspacecolony.ranch.Parcel;

public class ActionsPanel extends JPanel {
    private final MissionData mission; private final MapPanel map;

    public ActionsPanel(MissionData m, MapPanel map){
        this.mission=m; this.map=map;
        setLayout(new GridLayout(0,1,8,8));

        // Agricultura
        JButton buyMaize = new JButton("Comprar semillas Maíz (10/celda)");
        JButton buyApple = new JButton("Comprar semillas Manzano (15/celda)");
        JButton plantMaize = new JButton("Sembrar Maíz en celda");
        JButton plantApple = new JButton("Sembrar Manzano en celda");
        JButton installEx = new JButton("Instalar extractor (120)");
        JButton harvest = new JButton("Cosecha (FIFO)");
        JButton clean = new JButton("Limpiar celda (20)");
        JButton cleanAll = new JButton("Limpiar TODO (20/u)");

        // Mercado comida criaturas
        JButton buyHerbFood = new JButton("Comprar alimento herbívoro (x10)");
        JButton buyOmniFood = new JButton("Comprar alimento omnívoro (x10)");

        // NUEVO: Fertilizantes
        JButton buyFertA = new JButton("Comprar Fert A (+20%)");
        JButton buyFertB = new JButton("Comprar Fert B (+35%)");
        JButton buyFertC = new JButton("Comprar Fert C (+50%)");
        JButton applyFert = new JButton("Aplicar fertilizante a celda fértil");

        // Parcelas & crianza
        JButton createParcel = new JButton("Crear parcela (tamaño N)");
        JButton delParcel = new JButton("Eliminar parcela vacía (10)");
        JButton buyCow = new JButton("Comprar Vaca cósmica (60)");
        JButton buyChicken = new JButton("Comprar Gallina alienígena (20)");
        JButton collect = new JButton("Recolectar continua (parcela)");
        JButton slaughter = new JButton("Destazar todo (parcela)");
        JButton cleanCorpses = new JButton("Limpiar cadáveres parcela (10 c/u)");

        // Reportes
        JButton exportCrops = new JButton("Reporte Cultivos (HTML)");
        JButton exportCreatures = new JButton("Reporte Criaturas (HTML)");
        JButton exportSummary = new JButton("Reporte Resumen (HTML)");

        // Orden en panel
        add(buyMaize); add(buyApple); add(plantMaize); add(plantApple);
        add(installEx); add(harvest); add(clean); add(cleanAll);
        add(buyHerbFood); add(buyOmniFood);
        add(buyFertA); add(buyFertB); add(buyFertC); add(applyFert);
        add(createParcel); add(delParcel);
        add(buyCow); add(buyChicken);
        add(collect); add(slaughter); add(cleanCorpses);
        add(exportCrops); add(exportCreatures); add(exportSummary);

        // Listeners
        buyMaize.addActionListener(e -> buySeeds(true));
        buyApple.addActionListener(e -> buySeeds(false));
        plantMaize.addActionListener(e -> plant(true));
        plantApple.addActionListener(e -> plant(false));
        installEx.addActionListener(e -> installExtractor());
        harvest.addActionListener(e -> harvestFIFO());
        clean.addActionListener(e -> cleanCell());
        cleanAll.addActionListener(e -> cleanAllCells());
        buyHerbFood.addActionListener(e -> buyHerb());
        buyOmniFood.addActionListener(e -> buyOmni());
        buyFertA.addActionListener(e -> buyFert(Market.FERT_A));
        buyFertB.addActionListener(e -> buyFert(Market.FERT_B));
        buyFertC.addActionListener(e -> buyFert(Market.FERT_C));
        applyFert.addActionListener(e -> applyFert());
        createParcel.addActionListener(e -> createParcel());
        delParcel.addActionListener(e -> deleteParcel());
        buyCow.addActionListener(e -> buyCreature(true));
        buyChicken.addActionListener(e -> buyCreature(false));
        collect.addActionListener(e -> collectParcel());
        slaughter.addActionListener(e -> slaughterParcel());
        cleanCorpses.addActionListener(e -> cleanCorpses());
        exportCrops.addActionListener(e -> exportCrops());
        exportCreatures.addActionListener(e -> exportCreatures());
        exportSummary.addActionListener(e -> exportSummary());
    }

    // ===== Agricultura =====
    private void buySeeds(boolean maize){
        String s = JOptionPane.showInputDialog(this,"¿Cuántas celdas sembrarás?","1");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            if(maize) Market.buyMaizeSeeds(mission,n); else Market.buyAppleSeeds(mission,n);
            JOptionPane.showMessageDialog(this,"Semillas compradas");
        }catch(NotEnoughCreditsException ex){ msg(ex.getMessage()); }
    }
    private void plant(boolean maize){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda fértil"); return; }
        try{
            Product out = maize? Market.FOOD_GRAIN : Market.FOOD_FRUIT;
            Crop crop = maize? new MaizeCrop(out) : new AppleTreeCrop(out);
            mission.getGrid().placeCrop(r,c,crop);
            mission.getStats().fertileCellsPlanted++;
            if(maize) mission.getStats().maizeCellsPlanted++;
            else      mission.getStats().appleCellsPlanted++;
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void installExtractor(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una acuífera"); return; }
        try{
            mission.spendCredits(120);
            mission.getGrid().placeExtractor(r,c,new Extractor());
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void harvestFIFO(){
    if(mission.isHarvesting()){ Sound.error(); msg("Ya hay cosecha en curso"); return; }
    if(mission.harvestQueueSize()==0){ Sound.error(); msg("No hay cultivos listos en cola"); return; }
    mission.beginNextHarvest();
    Sound.success();
    msg("¡Cosecha iniciada (FIFO)!");
}

    private void cleanCell(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda"); return; }
        try{ mission.spendCredits(20); mission.getGrid().cleanCell(r,c); }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void cleanAllCells(){
        Grid g=mission.getGrid(); int rows=g.getRows(), cols=g.getCols();
        int cnt=0; for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) cnt++;
        if(cnt==0){ msg("No hay celdas arruinadas"); return; }
        int total=cnt*20; int ok=JOptionPane.showConfirmDialog(this,"Se limpiarán "+cnt+" celdas por "+total+" créditos. ¿Confirmar?","Limpiar TODO",JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{ mission.spendCredits(total); for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) g.get(r,c).clearAll(); }catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== Mercado comida criaturas =====
    private void buyHerb(){
        try{ Market.buyHerbFood(mission,10); msg("Compraste 10 de alimento herbívoro"); }
        catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void buyOmni(){
        try{ Market.buyOmniFood(mission,10); msg("Compraste 10 de alimento omnívoro"); }
        catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== NUEVO: Fertilizantes =====
    private void buyFert(Product fert){
        String s = JOptionPane.showInputDialog(this,"¿Cuántas unidades comprar?","1");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            if(fert==Market.FERT_A) Market.buyFertA(mission,n);
            else if(fert==Market.FERT_B) Market.buyFertB(mission,n);
            else Market.buyFertC(mission,n);
            msg("Compraste "+n+" de "+fert.name);
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void applyFert(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda fértil"); return; }
        Cell cl = mission.getGrid().get(r,c);
        if(cl.getTerrain()!=TerrainType.FERTILE){ msg("Solo en terreno fértil"); return; }

        String[] opts = { Market.FERT_A.name, Market.FERT_B.name, Market.FERT_C.name };
        int sel = JOptionPane.showOptionDialog(this, "¿Qué fertilizante aplicar?",
                "Aplicar fertilizante", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opts, opts[0]);
        if(sel<0) return;

        Product p = (sel==0? Market.FERT_A : sel==1? Market.FERT_B : Market.FERT_C);
        if(!mission.getInventory().consume(p,1)){ msg("No tienes "+p.name+" en bodega"); return; }
        double boost = Market.fertilizerBoost(p);
        cl.applyFertilizer(boost);
        msg("Aplicado "+p.name+". Fertilidad ahora: x" + String.format("%.2f", cl.getFertility()));
    }

    // ===== Parcelas & crianza =====
    private void createParcel(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona celda fértil de inicio"); return; }
        String s = JOptionPane.showInputDialog(this,"Tamaño de parcela (número de celdas fértiles contiguas):","2");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            Parcel p = mission.getGrid().createParcelFrom(r,c,n);
            msg("Parcela creada con id="+p.id+" y capacidad="+p.cells.size());
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void deleteParcel(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda de la parcela"); return; }
        try{
            mission.spendCredits(10);
            mission.getGrid().deleteParcelIfEmpty(r,c);
            msg("Parcela eliminada");
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void buyCreature(boolean cow){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda de la parcela"); return; }
        Parcel p = mission.getGrid().getParcelByCell(r,c);
        if(p==null){ msg("Aquí no hay parcela"); return; }
        try{
            if(cow){ mission.spendCredits(Market.COW_PRICE); if(!p.addCreature(new CosmicCow())){ msg("Sin espacio o especie incompatible"); mission.addCredits(Market.COW_PRICE); return; } mission.getStats().cowsBought++; }
            else   { mission.spendCredits(Market.CHICK_PRICE); if(!p.addCreature(new AlienChicken())){ msg("Sin espacio o especie incompatible"); mission.addCredits(Market.CHICK_PRICE); return; } mission.getStats().chicksBought++; }
            msg("Agregado a la parcela");
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void collectParcel(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        Parcel p = mission.getGrid().getParcelByCell(r,c); if(p==null){ msg("No hay parcela"); return; }
        int got = p.collectAll(mission);
        msg("Recolectado: "+got+" unidades");
    }
    private void slaughterParcel(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        Parcel p = mission.getGrid().getParcelByCell(r,c); if(p==null){ msg("No hay parcela"); return; }
        int before = mission.getStats().cowsSlaughtered + mission.getStats().chickensSlaughtered;
        int n = p.slaughterAll(mission);
        int after = mission.getStats().cowsSlaughtered + mission.getStats().chickensSlaughtered;
        int delta = after - before;
        if(n>0){ mission.getStats().slaughtered += n; msg("Destazados: "+delta); }
        else msg("Nada para destazar");
    }
    private void cleanCorpses(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        Parcel p = mission.getGrid().getParcelByCell(r,c); if(p==null){ msg("No hay parcela"); return; }
        int corps = p.corpses();
        if(corps==0){ msg("No hay cadáveres"); return; }
        int cost = corps * 10;
        int ok = JOptionPane.showConfirmDialog(this,"Se limpiarán "+corps+" cadáver(es) por "+cost+" créditos. ¿Confirmar?","Limpieza",JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{ mission.spendCredits(cost); p.cleanCorpses(); msg("Parcela limpia"); }catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== Reportes =====
    private void exportCrops(){
        java.io.File html = chooseFile("reporte_cultivos.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            MissionStats s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Cultivos</title>");
            pw.println("<h1>Reporte de Cultivos</h1>");
            pw.println("<table border=1 cellpadding=6>");
            pw.println("<tr><th>Concepto</th><th>Maíz (grano)</th><th>Manzano (fruta)</th><th>Total</th></tr>");
            pw.printf("<tr><td>Semillas compradas</td><td>%d</td><td>%d</td><td>%d</td></tr>",
                    s.seedsMaizeBought, s.seedsAppleBought, s.seedsMaizeBought+s.seedsAppleBought);
            pw.printf("<tr><td>Celdas sembradas</td><td>%d</td><td>%d</td><td>%d</td></tr>",
                    s.maizeCellsPlanted, s.appleCellsPlanted, s.fertileCellsPlanted);
            pw.printf("<tr><td>Alimento producido</td><td>%d (grano)</td><td>%d (fruta)</td><td>%d</td></tr>",
                    s.grainProduced, s.fruitProduced, s.totalFoodProduced);
            pw.println("</table>");
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    private void exportCreatures(){
        java.io.File html = chooseFile("reporte_criaturas.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            MissionStats s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Criaturas</title>");
            pw.println("<h1>Reporte de Criaturas</h1>");
            pw.println("<table border=1 cellpadding=6>");
            pw.println("<tr><th>Especie</th><th>Crías compradas</th><th>Destazadas</th><th>Producción continua</th><th>Materias/Alimentos por destace</th></tr>");
            pw.printf("<tr><td>Vaca cósmica</td><td>%d</td><td>%d</td><td>%d leche</td><td>%d cuero, %d carne</td></tr>",
                    s.cowsBought, s.cowsSlaughtered, s.milkProduced, s.leatherProduced, s.cowMeatProduced);
            pw.printf("<tr><td>Gallina alienígena</td><td>%d</td><td>%d</td><td>%d huevos</td><td>%d carne</td></tr>",
                    s.chicksBought, s.chickensSlaughtered, s.eggsProduced, s.chickenMeatProduced);
            pw.println("</table>");
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    private void exportSummary(){
        java.io.File html = chooseFile("reporte_resumen.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            long dur = mission.getDurationMs()/1000;
            MissionStats s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Resumen</title>");
            pw.printf("<h1>Resumen de misión</h1><p>Duración: %ds — Créditos actuales: %d — Salud: %d%%</p>",
                    dur, mission.getCredits(), mission.getCrewHealth());
            pw.println("<h2>Totales</h2>");
            pw.printf("<p>Alimento producido: %d | Consumido por tripulación: %d | Celdas sembradas: %d</p>",
                    s.totalFoodProduced, s.totalFoodConsumedCrew, s.fertileCellsPlanted);
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    // ===== util =====
    private java.io.File chooseFile(String def){
        javax.swing.JFileChooser ch = new javax.swing.JFileChooser();
        ch.setSelectedFile(new java.io.File(def));
        int r=ch.showSaveDialog(this);
        return r==javax.swing.JFileChooser.APPROVE_OPTION? ch.getSelectedFile(): null;
    }
    private void msg(String s){ JOptionPane.showMessageDialog(this,s); }
}
