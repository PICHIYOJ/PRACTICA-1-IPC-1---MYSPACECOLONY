package com.myspacecolony.ranch;
public enum SpeciesKind { HERBIVORE, OMNIVORE }
