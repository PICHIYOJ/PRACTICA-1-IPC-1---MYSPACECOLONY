package com.myspacecolony.core;


public class RandomUtil {
public static long range(long min, long max){
return min + (long)((max-min)*Math.random());
}
}