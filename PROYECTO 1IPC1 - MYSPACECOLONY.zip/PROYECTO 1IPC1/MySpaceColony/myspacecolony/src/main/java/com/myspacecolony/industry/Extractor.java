package com.myspacecolony.industry;


import com.myspacecolony.core.MissionData;


public class Extractor implements java.io.Serializable {
private int capacity = 100; // recursos restantes
private boolean active=true;


public static final int PRICE=120; // caro


public void update(long dt, MissionData mission){
if(!active) return;
// cada segundo extrae 1 unidad y la vende automáticamente
// para demo: 1 unidad ~ 2 créditos
mission.addCredits(2);
mission.getStats().creditsGenerated += 2;
capacity--;
if(capacity<=0){ active=false; }
}


public boolean isDepleted(){ return !active; }
public void remove(){ active=false; }
}