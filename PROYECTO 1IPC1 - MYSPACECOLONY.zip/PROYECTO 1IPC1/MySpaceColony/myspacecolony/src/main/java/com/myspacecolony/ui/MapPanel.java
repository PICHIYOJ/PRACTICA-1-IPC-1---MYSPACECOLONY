package com.myspacecolony.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import com.myspacecolony.core.Cell;
import com.myspacecolony.core.Grid;
import com.myspacecolony.core.MissionData;
import com.myspacecolony.farming.Crop;


public class MapPanel extends JPanel {
    private final MissionData mission;
    private int selR = -1, selC = -1;

    public MapPanel(MissionData mission){
        this.mission = mission;
        setPreferredSize(new Dimension(620, 620));
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                Grid g = mission.getGrid();
                int cellSize = Math.min(getWidth()/g.getCols(), getHeight()/g.getRows());
                selR = e.getY()/cellSize;
                selC = e.getX()/cellSize;
                repaint();
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter(){
        @Override public void mouseMoved(java.awt.event.MouseEvent e){
            Grid g = mission.getGrid();
            int cellSize = Math.min(getWidth()/g.getCols(), getHeight()/g.getRows());
            int rr = e.getY()/cellSize, cc = e.getX()/cellSize;
            if(rr<0 || cc<0 || rr>=g.getRows() || cc>=g.getCols()){ 
                setToolTipText(null); 
                return; 
            }
            Cell cl = g.get(rr,cc);
            String terr = switch(cl.getTerrain()){
                case FERTILE -> "Fértil";
                case AQUIFER -> "Acuífero";
                default -> "Árido";
            };
            String fert = String.format("x%.2f", cl.getFertility());
            String crop = (cl.getCrop()!=null ? (cl.getCrop().isGrain()?"Grano":"Fruta") + (cl.getCrop().isReady()?" (listo)":"") : "—");
            String ex = (cl.getExtractor()!=null ? "Sí" : "No");
            String par = (cl.getParcelId()>=0 ? "#"+cl.getParcelId() : "—");
            setToolTipText("<html>Terreno: "+terr+"<br>Fertilidad: "+fert+"<br>Cultivo: "+crop+"<br>Extractor: "+ex+"<br>Parcela: "+par+"</html>");
        }
    });
    }

    public int getSelR(){ return selR; }
    public int getSelC(){ return selC; }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Grid grid = mission.getGrid();
        int rows = grid.getRows(), cols = grid.getCols();
        int cell = Math.min(getWidth()/cols, getHeight()/rows);

        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++){
                Cell cl = grid.get(r,c);
                switch (cl.getTerrain()) {
                    case FERTILE -> g.setColor(new Color(60,170,80));
                    case AQUIFER -> g.setColor(new Color(70,140,210));
                    case ARID    -> g.setColor(new Color(220,140,60));
                }
                int x = c*cell, y = r*cell;
                g.fillRect(x, y, cell-2, cell-2);

                if (cl.getCrop()!=null) {
                    g.setColor(Color.BLACK);
                    Crop cr = cl.getCrop();
                    g.drawString(cr.isGrain() ? "G" : "F", x+cell/2-4, y+cell/2);
                    if (cr.isReady()) {
                        g.setColor(Color.YELLOW);
                        g.drawOval(x+4, y+4, cell-12, cell-12);
                    }
                }
                if (cl.getExtractor()!=null) {
                    g.setColor(Color.DARK_GRAY);
                    g.fillRect(x+cell/4, y+cell/4, cell/2, cell/2);
                }
                if (cl.getParcelId()>=0){
    g.setColor(new Color(0,255,255));
    g.drawRect(x+2, y+2, cell-6, cell-6);
}
                if (cl.isRuined()) {
                    g.setColor(new Color(90,0,0));
                    g.drawLine(x, y, x+cell-2, y+cell-2);
                    g.drawLine(x+cell-2, y, x, y+cell-2);
                }
            }
        }

        if (selR>=0 && selC>=0) {
            g.setColor(Color.WHITE);
            g.drawRect(selC*cell, selR*cell, cell-2, cell-2);
        }
    }
}
