package com.myspacecolony.ui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.myspacecolony.core.MissionData;

public class HUDPanel extends JPanel {
    private final MissionData mission;
    private final JLabel lbl;

    public HUDPanel(MissionData m){
        this.mission=m;
        setLayout(new BorderLayout());
        lbl = new JLabel();
        lbl.setFont(lbl.getFont().deriveFont(Font.BOLD, 14f));
        add(lbl, BorderLayout.WEST);
        refresh();
    }

    public void refresh(){
        String cola = "Cola: " + mission.harvestQueueSize();
        String cosecha = mission.isHarvesting()
                ? " | Cosechando… " + Math.max(0, mission.getHarvestRemainingMs()/1000) + "s"
                : "";
        lbl.setText("Comandante: " + mission.getCredits() + " créditos | Salud tripulación: "
                + mission.getCrewHealth() + "% | " + cola + cosecha);
    }
}
