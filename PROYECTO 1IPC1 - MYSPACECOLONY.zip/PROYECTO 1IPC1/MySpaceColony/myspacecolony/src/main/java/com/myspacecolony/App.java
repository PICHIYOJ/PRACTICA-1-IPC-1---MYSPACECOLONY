package com.myspacecolony;


import com.myspacecolony.core.MissionData;
import com.myspacecolony.ui.MainWindow;


public class App {
public static void main(String[] args) {
// Datos iniciales de misión
MissionData mission = MissionData.createDefault("Comandante", "nick");
javax.swing.SwingUtilities.invokeLater(() -> new MainWindow(mission).setVisible(true));
}
}