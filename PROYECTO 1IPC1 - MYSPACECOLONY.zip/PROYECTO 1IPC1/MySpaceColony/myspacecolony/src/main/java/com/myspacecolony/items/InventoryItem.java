package com.myspacecolony.items;

public class InventoryItem implements java.io.Serializable {
    public final Product product;
    public int qty;
    public InventoryItem(Product p, int q){ this.product=p; this.qty=q; }
}
