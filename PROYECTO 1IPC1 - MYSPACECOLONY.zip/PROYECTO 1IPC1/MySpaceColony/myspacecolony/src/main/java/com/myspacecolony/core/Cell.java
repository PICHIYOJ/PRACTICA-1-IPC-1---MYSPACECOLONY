package com.myspacecolony.core;

import com.myspacecolony.farming.Crop;
import com.myspacecolony.industry.Extractor;

public class Cell implements java.io.Serializable {
    public final int row, col;
    private TerrainType terrain;
    private Crop crop;
    private Extractor extractor;
    private boolean ruined;

    // === NUEVO: fertilidad (1.0 por defecto; máx 2.0) ===
    private double fertility = 1.0;
    public double getFertility(){ return fertility; }
    public void applyFertilizer(double boost){
        fertility = Math.min(2.0, fertility + boost);
    }

    // === Parcela (ya lo tenías en Fase 2) ===
    int parcelId = -1;
    public int getParcelId(){ return parcelId; }
    public void setParcelId(int id){ parcelId = id; }

    public Cell(int r, int c, TerrainType t) { this.row=r; this.col=c; this.terrain=t; }

    public TerrainType getTerrain(){ return terrain; }
    public Crop getCrop(){ return crop; }
    public Extractor getExtractor(){ return extractor; }
    public boolean isRuined(){ return ruined; }

    public void setCrop(Crop c){ crop=c; extractor=null; }
    public void setExtractor(Extractor e){ extractor=e; crop=null; }
    public void setRuined(boolean r){ ruined=r; }
    public void clearAll(){ crop=null; extractor=null; ruined=false; }
}
