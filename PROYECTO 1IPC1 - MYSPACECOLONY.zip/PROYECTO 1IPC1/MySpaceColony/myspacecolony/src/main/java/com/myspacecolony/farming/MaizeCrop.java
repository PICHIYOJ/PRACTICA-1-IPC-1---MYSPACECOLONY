package com.myspacecolony.farming;

import com.myspacecolony.items.Product;

public class MaizeCrop extends Crop {
    public MaizeCrop(Product output){
        super("Maíz espacial", true, 6000, output, 2000, 3500);
    }
    @Override public int baseYield(){ return 8 + (int)(Math.random()*5); }
    @Override public boolean diesOnHarvest(){ return true; }
}
