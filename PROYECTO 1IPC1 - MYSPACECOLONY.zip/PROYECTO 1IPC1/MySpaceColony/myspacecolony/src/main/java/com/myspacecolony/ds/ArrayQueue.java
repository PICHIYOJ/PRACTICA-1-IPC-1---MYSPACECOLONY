package com.myspacecolony.ds;


public class ArrayQueue<T> implements java.io.Serializable{
private Object[] data=new Object[8];
private int head=0, tail=0, count=0;


public void enqueue(T v){
if(count==data.length) grow();
data[tail]=v; tail=(tail+1)%data.length; count++;
}
@SuppressWarnings("unchecked")
public T dequeue(){
if(count==0) return null;
T v=(T)data[head]; data[head]=null; head=(head+1)%data.length; count--; return v;
}
public boolean isEmpty(){ return count==0; }
public int size(){ return count; }


private void grow(){
Object[] nd=new Object[data.length*2];
for(int i=0;i<count;i++) nd[i]=data[(head+i)%data.length];
data=nd; head=0; tail=count;
}
}