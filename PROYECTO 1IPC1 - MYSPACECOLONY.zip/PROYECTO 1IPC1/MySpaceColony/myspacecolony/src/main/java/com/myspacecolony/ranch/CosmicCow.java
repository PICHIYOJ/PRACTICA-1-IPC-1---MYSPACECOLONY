package com.myspacecolony.ranch;

import com.myspacecolony.market.Market;

public class CosmicCow extends Creature  {
    public CosmicCow(){
        super("Vaca cósmica", SpeciesKind.HERBIVORE, 2.0);
        this.contProduct = Market.MILK; this.contBase = 3;
        this.killA = Market.LEATHER; this.killAPercent = 25;
        this.killB = Market.COW_MEAT; this.killBPercent = 75;
    }
}
