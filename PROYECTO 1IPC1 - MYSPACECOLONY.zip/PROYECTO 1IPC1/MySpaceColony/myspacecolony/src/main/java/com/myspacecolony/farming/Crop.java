package com.myspacecolony.farming;

import com.myspacecolony.core.MissionData;
import com.myspacecolony.items.Product;

public abstract class Crop implements Harvestable {
    protected final String name;
    protected final boolean grain;             // true=grano, false=fruta
    protected long growTimeMs;
    protected long plantedAt;
    protected boolean ready = false;
    protected boolean queued = false;
    protected Product output;

    // cosecha
    protected long harvestMinMs;
    protected long harvestMaxMs;

    // NUEVO: factor de fertilidad de la celda [0.5 .. 2.0]
    protected double fertilityFactor = 1.0;
    public void setFertilityFactor(double f){ fertilityFactor = Math.max(0.5, Math.min(2.0, f)); }

    public Crop(String name, boolean grain, long growTimeMs, Product output,
                long harvestMinMs, long harvestMaxMs) {
        this.name = name; this.grain = grain; this.growTimeMs = growTimeMs;
        this.output = output;
        this.harvestMinMs = harvestMinMs; this.harvestMaxMs = harvestMaxMs;
        this.plantedAt = System.currentTimeMillis();
    }

    public String getName() { return name; }
    public boolean isGrain() { return grain; }

    public void update(long dt, MissionData mission){
        if(!ready){
            if(System.currentTimeMillis() - plantedAt >= growTimeMs) ready = true;
        }
    }

    public boolean isReady(){ return ready; }
    public boolean isQueued(){ return queued; }
    public void setQueued(boolean q){ queued = q; }

    public long harvestDurationMs(){
        if(harvestMaxMs <= harvestMinMs) return harvestMinMs;
        return harvestMinMs + (long)(Math.random() * (harvestMaxMs - harvestMinMs));
    }

    public abstract int baseYield();
    public abstract boolean diesOnHarvest();

    public void harvest(MissionData mission){
        if(!ready) return;
        // rendimiento multiplicado por fertilidad
        int qty = (int)Math.max(1, Math.round(baseYield() * fertilityFactor));
        mission.getInventory().add(output, qty);
        mission.getStats().totalFoodProduced += qty;
        if (grain) mission.getStats().grainProduced += qty;
        else       mission.getStats().fruitProduced += qty;

        ready = false;
        queued = false;

        if(!diesOnHarvest()){
            long var = (long)(growTimeMs * 0.15);
            long newTime = growTimeMs + (long)((Math.random()*2 - 1) * var);
            plantedAt = System.currentTimeMillis();
            growTimeMs = Math.max(2000, newTime);
        }
    }
}
