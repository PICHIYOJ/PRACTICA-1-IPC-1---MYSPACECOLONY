package com.myspacecolony.ranch;

import com.myspacecolony.core.MissionData;
import com.myspacecolony.items.Product;
import com.myspacecolony.market.Market;

public abstract class Creature implements java.io.Serializable {
    protected final String name;
    protected final SpeciesKind kind;
    protected final double space; // celdas requeridas (ej: 2.0 vaca, 0.5 gallina)
    protected boolean alive = true;

    // Auto-alimentación (hasta 5)
    protected final Product[] prefs = new Product[5];
    protected int prefN = 0;

    // Estado
    protected long ageMs = 0;          // edad
    protected long hungerMs = 0;       // hambre acumulada
    protected long starveMs = 0;       // tiempo sin comer

    // Producción continua
    protected Product contProduct = null;
    protected int contBase = 0;  // unidades por recolección

    // Producción por destace (dos productos con porcentajes)
    protected Product killA = null; protected int killAPercent = 0;
    protected Product killB = null; protected int killBPercent = 0;

    public Creature(String name, SpeciesKind kind, double space){
        this.name=name; this.kind=kind; this.space=space;
        // defaults de comida
        if(kind==SpeciesKind.HERBIVORE){ addPref(Market.HERB1); addPref(Market.HERB2); addPref(Market.HERB3); }
        else { addPref(Market.OMNI1); addPref(Market.OMNI2); addPref(Market.OMNI3); }
    }

    protected void addPref(Product p){ if(prefN<5) prefs[prefN++] = p; }

    public String getName(){ return name; }
    public boolean isAlive(){ return alive; }
    public double spaceRequired(){ return space; }

    /** Avance del tiempo; intenta comer si tiene hambre */
    public void tick(long dt, MissionData m){
        if(!alive) return;
        ageMs += dt;
        hungerMs += dt;

        if(hungerMs >= hungerPeriodMs()){
            // intenta consumir 1 unidad de alguna preferencia
            boolean ate=false;
            for(int i=0;i<prefN;i++){
                if(m.getInventory().consume(prefs[i], 1)){ ate=true; break; }
            }
            if(ate){ hungerMs = 0; starveMs = 0; }
            else { starveMs += hungerPeriodMs(); }
        }

        // muerte por inanición o vejez
        if(starveMs >= maxStarveMs() || ageMs >= maxAgeMs()){
            alive=false;
            // ocupa espacio hasta limpiar; limpieza la hace la parcela
        }
    }

    /** Recolección continua (leche, huevos). Devuelve unidades producidas */
  public int collect(MissionData m){
    if(!alive || contProduct==null) return 0;
    int mult = ageMs < juvenileMs()? 50 : ageMs > elderMs()? 50 : 100;
    int qty = contBase * mult / 100;
    m.getInventory().add(contProduct, qty);
    // === acumular en estadísticas ===
    if(contProduct == Market.MILK) m.getStats().milkProduced += qty;
    if(contProduct == Market.EGGS) m.getStats().eggsProduced += qty;
    return qty;
}

public void slaughter(MissionData m){
    if(!alive) return;

    int total = killAPercent + killBPercent;
    // Si la especie no tiene porcentajes de destace, igual muere pero no entrega nada.
    if (total <= 0) { 
        alive = false; 
        return; 
    }

    int base = 10; // producción base de destace (demo)

    if(killAPercent > 0){
        int q = base * killAPercent / 100;
        m.getInventory().add(killA, q);
        if(killA == Market.LEATHER)         m.getStats().leatherProduced      += q;
        if(killA == Market.COW_MEAT)        m.getStats().cowMeatProduced      += q;
        if(killA == Market.CHICKEN_MEAT)    m.getStats().chickenMeatProduced  += q;
    }

    if(killBPercent > 0){
        int q = base * killBPercent / 100;
        m.getInventory().add(killB, q);
        if(killB == Market.LEATHER)         m.getStats().leatherProduced      += q;
        if(killB == Market.COW_MEAT)        m.getStats().cowMeatProduced      += q;
        if(killB == Market.CHICKEN_MEAT)    m.getStats().chickenMeatProduced  += q;
    }

    if(kind == SpeciesKind.HERBIVORE) m.getStats().cowsSlaughtered++;
    else                              m.getStats().chickensSlaughtered++;

    alive = false;
}



    // parámetros de especie
    protected long hungerPeriodMs(){ return 5_000; }
    protected long maxStarveMs(){ return 30_000; }
    protected long maxAgeMs(){ return 5*60_000; } // 5 minutos demo
    protected long juvenileMs(){ return 30_000; }
    protected long elderMs(){ return 4*60_000; }
}
