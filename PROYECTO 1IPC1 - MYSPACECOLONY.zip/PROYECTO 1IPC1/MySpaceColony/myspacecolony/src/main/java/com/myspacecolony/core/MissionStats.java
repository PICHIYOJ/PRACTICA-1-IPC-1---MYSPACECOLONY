package com.myspacecolony.core;

public class MissionStats implements java.io.Serializable {
    // generales
    public int creditsGenerated;
    public int totalFoodProduced;
    public int totalFoodConsumedCrew;

    // cultivos
    public int seedsMaizeBought, seedsAppleBought;
    public int fertileCellsPlanted;   // total
    public int maizeCellsPlanted, appleCellsPlanted;
    public int grainProduced, fruitProduced;

    // criaturas
    public int cowsBought, chicksBought;
    public int cowsSlaughtered, chickensSlaughtered;
    public int milkProduced, eggsProduced;
    public int leatherProduced, cowMeatProduced, chickenMeatProduced;
    public int slaughtered;
}
