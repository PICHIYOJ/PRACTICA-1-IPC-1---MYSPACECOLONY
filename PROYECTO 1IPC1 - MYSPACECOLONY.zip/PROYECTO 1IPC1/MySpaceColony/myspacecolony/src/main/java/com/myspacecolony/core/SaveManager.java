package com.myspacecolony.core;

public class SaveManager {
    // 3 ranuras en memoria
    private static byte[][] slots = new byte[3][];
    private static String[] names = new String[]{"Ranura 1","Ranura 2","Ranura 3"};

    public static boolean save(int slotIndex, MissionData m){
        if(slotIndex<0 || slotIndex>=slots.length) return false;
        // quitar referencias UI antes de serializar
        m.attachWindow(null);
        slots[slotIndex] = SerializationUtil.toBytes(m);
        return true;
    }

    public static MissionData load(int slotIndex){
        if(slotIndex<0 || slotIndex>=slots.length) return null;
        if(slots[slotIndex]==null) return null;
        return SerializationUtil.fromBytes(slots[slotIndex], MissionData.class);
    }

    public static String slotName(int i){ return names[i]; }
    public static boolean hasData(int i){ return slots[i]!=null; }
}
