package com.myspacecolony.core;


public enum TerrainType {
FERTILE, AQUIFER, ARID;
}