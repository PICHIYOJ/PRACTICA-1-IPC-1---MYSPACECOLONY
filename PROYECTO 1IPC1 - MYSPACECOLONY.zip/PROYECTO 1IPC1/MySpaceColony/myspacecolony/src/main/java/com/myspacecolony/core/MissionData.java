package com.myspacecolony.core;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Optional;

import com.myspacecolony.ds.ArrayQueue;
import com.myspacecolony.farming.Crop;
import com.myspacecolony.items.Inventory;
import com.myspacecolony.ui.MainWindow;

public class MissionData implements java.io.Serializable{
    private final String commanderName;
    private final String nick;
    private final long startTime;

    private int crewHealth;     // vida de tripulación
    private int credits;        // créditos

    private final Grid grid;
    private transient com.myspacecolony.ui.MainWindow window; // referencia UI (no serializar)

    private final MissionStats stats = new MissionStats();
    private final com.myspacecolony.items.Inventory inventory = new Inventory();

    // bitácora binaria simple
    private final File binLog = new File("mission_log.bin");

    // ===== FASE 2: Cola de cosecha (FIFO) =====
    private final ArrayQueue<Cell> harvestQueue = new ArrayQueue<>();
    private boolean harvesting = false;
    private Cell harvestingCell = null;
    private long harvestRemainingMs = 0;

    private MissionData(String name,String nick,int credits,int health){
        this.commanderName=name; this.nick=nick; this.credits=credits; this.crewHealth=health;
        this.startTime=System.currentTimeMillis();
        this.grid=new Grid(5,5);
    }

    public static MissionData createDefault(String name,String nick){
        return new MissionData(name,nick, 500, 100);
    }

    // ===== getters básicos =====
    public String getCommanderName(){ return commanderName; }
    public String getNick(){ return nick; }
    public Grid getGrid(){ return grid; }
    public Inventory getInventory(){ return inventory; }
    public MissionStats getStats(){ return stats; }
    public long getDurationMs(){ return System.currentTimeMillis()-startTime; }

    public int getCredits(){ return credits; }
    public void addCredits(int amt){ credits+=amt; }
    public void spendCredits(int amt) throws com.myspacecolony.core.Exceptions.NotEnoughCreditsException {
        if(credits<amt) throw new com.myspacecolony.core.Exceptions.NotEnoughCreditsException();
        credits-=amt;
    }

    public int getCrewHealth(){ return crewHealth; }
    public void decCrewHealth(int d){ crewHealth=Math.max(0, crewHealth-d); }
    public void addCrewHealth(int d){ crewHealth=Math.min(100, crewHealth+d); }

    public void attachWindow(MainWindow w){ this.window=w; }
    public Optional<MainWindow> getWindowRef(){ return Optional.ofNullable(window); }

    // ===== Cola de cosecha API =====
    public void enqueueReady(Cell cell){
        if(cell==null) return;
        Crop c = cell.getCrop();
        if(c!=null && c.isReady() && !c.isQueued()){
            harvestQueue.enqueue(cell);
            c.setQueued(true);
        }
    }
    public int harvestQueueSize(){ return harvestQueue.size(); }
    public boolean isHarvesting(){ return harvesting; }
    public long getHarvestRemainingMs(){ return harvestRemainingMs; }

    /** Lanza la siguiente cosecha si hay en cola */
    public void beginNextHarvest(){
        if(harvesting || harvestQueue.isEmpty()) return;
        harvestingCell = harvestQueue.dequeue();
        if(harvestingCell==null) return;
        Crop crop = harvestingCell.getCrop();
        if(crop==null) return;
        harvesting = true;
        harvestRemainingMs = crop.harvestDurationMs();
    }

    /** Avanza el temporizador de la cosecha en curso; cuando termina, cosecha realmente */
    public void tickHarvest(long dt){
    if(!harvesting) return;
    harvestRemainingMs -= dt;
    if(harvestRemainingMs <= 0){
        com.myspacecolony.farming.Crop crop = harvestingCell.getCrop();
        if(crop != null){
            crop.harvest(this);
            if(crop.diesOnHarvest()) harvestingCell.clearAll();
        }
        harvesting = false;
        harvestingCell = null;
        harvestRemainingMs = 0;

        // 🔔 Beep de fin de cosecha:
        Sound.event();
    }
}


    // ===== Bin log =====
    public void writeBinEvent(int code, int value){
        try(DataOutputStream out = new DataOutputStream(new FileOutputStream(binLog,true))){
            out.writeLong(System.currentTimeMillis());
            out.writeInt(code);
            out.writeInt(value);
        }catch(IOException ignored){}
    }
}
