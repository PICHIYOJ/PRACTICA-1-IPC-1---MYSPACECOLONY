package com.myspacecolony.ranch;

import com.myspacecolony.market.Market;

public class AlienChicken extends Creature {
    public AlienChicken(){
        super("Gallina alienígena", SpeciesKind.OMNIVORE, 0.5);
        this.contProduct = Market.EGGS; this.contBase = 2;
        this.killA = Market.CHICKEN_MEAT; this.killAPercent = 100;
    }
}
