package com.myspacecolony.items;

public class Product implements java.io.Serializable {
    public enum Kind { FOOD, RAW, TECH }
    public final String name;
    public final Kind kind;

    public Product(String name, Kind kind){
        this.name = name; this.kind = kind;
    }

    @Override public String toString(){ return name; }
}
