package com.myspacecolony.ds;


@SuppressWarnings("unchecked")
public class DynamicArray<T> implements java.io.Serializable{
private Object[] data = new Object[8];
private int size=0;


public void add(T v){
if(size==data.length){
Object[] nd=new Object[data.length*2];
System.arraycopy(data,0,nd,0,data.length);
data=nd;
}
data[size++]=v;
}


public T get(int idx){ return (T)data[idx]; }
public void set(int idx,T v){ data[idx]=v; }
public int size(){ return size; }


public void removeAt(int idx){
    if(idx<0 || idx>=size) return;
    for(int i=idx;i<size-1;i++) data[i] = data[i+1];
    size--;
}

}