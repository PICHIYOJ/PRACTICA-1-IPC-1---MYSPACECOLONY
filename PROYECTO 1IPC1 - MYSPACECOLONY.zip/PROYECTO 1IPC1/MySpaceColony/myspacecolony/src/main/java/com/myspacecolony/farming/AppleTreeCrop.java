package com.myspacecolony.farming;

import com.myspacecolony.items.Product;

public class AppleTreeCrop extends Crop {
    private int cyclesLeft = 3; // muere tras varios cortes
    public AppleTreeCrop(Product output){
        super("Manzano alienígena", false, 8000, output, 1500, 2500);
    }
    @Override public int baseYield(){ return 4 + (int)(Math.random()*4); }
    @Override public boolean diesOnHarvest(){ return --cyclesLeft <= 0; }
}
