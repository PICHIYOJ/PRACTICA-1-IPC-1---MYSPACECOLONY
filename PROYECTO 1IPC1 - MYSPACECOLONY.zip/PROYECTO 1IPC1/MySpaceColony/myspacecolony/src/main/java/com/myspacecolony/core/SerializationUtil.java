package com.myspacecolony.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationUtil {
    public static byte[] toBytes(Object o){
        try(ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(bos)){
            out.writeObject(o);
            out.flush();
            return bos.toByteArray();
        }catch(IOException e){ throw new RuntimeException(e); }
    }
    @SuppressWarnings("unchecked")
    public static <T> T fromBytes(byte[] data, Class<T> cls){
        try(ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ObjectInputStream in = new ObjectInputStream(bis)){
            Object o = in.readObject();
            return (T) o;
        }catch(IOException | ClassNotFoundException e){ throw new RuntimeException(e); }
    }
}
