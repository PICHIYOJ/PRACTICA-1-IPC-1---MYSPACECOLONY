package com.myspacecolony.market;

import com.myspacecolony.core.Exceptions.NotEnoughCreditsException;
import com.myspacecolony.core.MissionData;
import com.myspacecolony.items.Product;

public class Market {
    // Productos base
    public static final Product FOOD_GRAIN = new Product("Grano", Product.Kind.FOOD);
    public static final Product FOOD_FRUIT = new Product("Fruta", Product.Kind.FOOD);

    // Alimentos para criaturas
    public static final Product HERB1 = new Product("Forraje básico", Product.Kind.FOOD);
    public static final Product HERB2 = new Product("Pellets verdes", Product.Kind.FOOD);
    public static final Product HERB3 = new Product("Suplemento vegetal", Product.Kind.FOOD);
    public static final Product OMNI1 = new Product("Pienso mixto", Product.Kind.FOOD);
    public static final Product OMNI2 = new Product("Larvas proteicas", Product.Kind.FOOD);
    public static final Product OMNI3 = new Product("Pasta energética", Product.Kind.FOOD);

    // Producción criaturas
    public static final Product MILK = new Product("Leche cósmica", Product.Kind.FOOD);
    public static final Product EGGS = new Product("Huevos alienígenas", Product.Kind.FOOD);
    public static final Product COW_MEAT = new Product("Carne interplanetaria", Product.Kind.FOOD);
    public static final Product LEATHER = new Product("Cuero espacial", Product.Kind.RAW);
    public static final Product CHICKEN_MEAT = new Product("Carne alienígena", Product.Kind.FOOD);

    // Semillas
    public static final int MAIZE_SEED_PRICE = 10;
    public static final int APPLE_SEED_PRICE = 15;

    // Alimento criaturas (precio por unidad)
    public static final int HERB_PRICE = 3;
    public static final int OMNI_PRICE = 4;

    // Crías
    public static final int COW_PRICE = 60;
    public static final int CHICK_PRICE = 20;

    // === NUEVO: 3 fertilizantes ===
    public static final Product FERT_A = new Product("Fert A (+20%)", Product.Kind.TECH);
    public static final Product FERT_B = new Product("Fert B (+35%)", Product.Kind.TECH);
    public static final Product FERT_C = new Product("Fert C (+50%)", Product.Kind.TECH);
    public static final int PRICE_FERT_A = 12;
    public static final int PRICE_FERT_B = 18;
    public static final int PRICE_FERT_C = 25;
    public static final double BOOST_FERT_A = 0.20;
    public static final double BOOST_FERT_B = 0.35;
    public static final double BOOST_FERT_C = 0.50;

    public static double fertilizerBoost(Product p){
        if(p==FERT_A) return BOOST_FERT_A;
        if(p==FERT_B) return BOOST_FERT_B;
        if(p==FERT_C) return BOOST_FERT_C;
        return 0.0;
    }

    // ===== Compras =====
    public static void buyMaizeSeeds(MissionData m, int cells) throws NotEnoughCreditsException {
        m.spendCredits(cells * MAIZE_SEED_PRICE);
        m.getStats().seedsMaizeBought += cells;
    }
    public static void buyAppleSeeds(MissionData m, int cells) throws NotEnoughCreditsException {
        m.spendCredits(cells * APPLE_SEED_PRICE);
        m.getStats().seedsAppleBought += cells;
    }

    public static void buyHerbFood(MissionData m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * HERB_PRICE);
        m.getInventory().add(HERB1, units);
    }
    public static void buyOmniFood(MissionData m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * OMNI_PRICE);
        m.getInventory().add(OMNI1, units);
    }

    public static void buyFertA(MissionData m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_A);
        m.getInventory().add(FERT_A, units);
    }
    public static void buyFertB(MissionData m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_B);
        m.getInventory().add(FERT_B, units);
    }
    public static void buyFertC(MissionData m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_C);
        m.getInventory().add(FERT_C, units);
    }
}
