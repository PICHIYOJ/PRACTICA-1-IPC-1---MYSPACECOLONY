package com.myspacecolony.items;

import com.myspacecolony.ds.DynamicArray;

public class Inventory implements java.io.Serializable{
    private final DynamicArray<InventoryItem> items = new DynamicArray<>();

    public void add(Product p, int q){
        if(q<=0) return;
        int idx = indexOf(p);
        if(idx>=0) items.get(idx).qty += q;
        else items.add(new InventoryItem(p, q));
    }
    public boolean consume(Product p, int q){
        int idx = indexOf(p);
        if(idx<0) return false;
        InventoryItem it = items.get(idx);
        if(it.qty<q) return false;
        it.qty -= q;
        return true;
    }
    public int qty(Product p){
        int idx = indexOf(p);
        return idx<0 ? 0 : items.get(idx).qty;
    }
    private int indexOf(Product p){
        for(int i=0;i<items.size();i++) if(items.get(i).product==p) return i; // por referencia
        return -1;
    }
}
