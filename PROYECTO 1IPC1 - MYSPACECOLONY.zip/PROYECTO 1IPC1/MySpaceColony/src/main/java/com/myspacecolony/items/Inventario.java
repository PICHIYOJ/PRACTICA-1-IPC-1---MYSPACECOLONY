package com.myspacecolony.items;

import com.myspacecolony.ds.ArregloDinamico;

public class Inventario implements java.io.Serializable{
    private final ArregloDinamico<InventarioItems> items = new ArregloDinamico<>();

    public void add(Productos p, int q){
        if(q<=0) return;
        int idx = indexOf(p);
        if(idx>=0) items.get(idx).qty += q;
        else items.add(new InventarioItems(p, q));
    }
    public boolean consume(Productos p, int q){
        int idx = indexOf(p);
        if(idx<0) return false;
        InventarioItems it = items.get(idx);
        if(it.qty<q) return false;
        it.qty -= q;
        return true;
    }
    public int qty(Productos p){
        int idx = indexOf(p);
        return idx<0 ? 0 : items.get(idx).qty;
    }
    private int indexOf(Productos p){
        for(int i=0;i<items.size();i++) if(items.get(i).product==p) return i; // por referencia
        return -1;
    }
}
