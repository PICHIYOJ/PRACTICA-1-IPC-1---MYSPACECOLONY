package com.myspacecolony.core;

import com.myspacecolony.farming.Cultivo;
import com.myspacecolony.industry.Extractor;

public class Celda implements java.io.Serializable {
    public final int fila, columna;
    private TipoSuelo terreno;
    private Cultivo cultivo;
    private Extractor extractor;
    private boolean arruinado;

    // === NUEVO: fertilidad (1.0 por defecto; máx 2.0) ===
    private double fertilidad = 1.0;
    public double getFertility(){ return fertilidad; }
    public void applyFertilizer(double boost){
        fertilidad = Math.min(2.0, fertilidad + boost);
    }

    // === Parcela (ya lo tenías en Fase 2) ===
    int parcelId = -1;
    public int getParcelId(){ return parcelId; }
    public void setParcelId(int id){ parcelId = id; }

    public Celda(int r, int c, TipoSuelo t) { this.fila=r; this.columna=c; this.terreno=t; }

    public TipoSuelo getTerrain(){ return terreno; }
    public Cultivo getCrop(){ return cultivo; }
    public Extractor getExtractor(){ return extractor; }
    public boolean isRuined(){ return arruinado; }

    public void setCrop(Cultivo c){ cultivo=c; extractor=null; }
    public void setExtractor(Extractor e){ extractor=e; cultivo=null; }
    public void setRuined(boolean r){ arruinado=r; }
    public void clearAll(){ cultivo=null; extractor=null; arruinado=false; }
    
    
}
