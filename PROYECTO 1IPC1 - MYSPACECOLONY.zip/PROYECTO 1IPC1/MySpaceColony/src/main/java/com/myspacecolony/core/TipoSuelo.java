package com.myspacecolony.core;


public enum TipoSuelo {
FERTIL, ACUIFERO, ARIDO;
}