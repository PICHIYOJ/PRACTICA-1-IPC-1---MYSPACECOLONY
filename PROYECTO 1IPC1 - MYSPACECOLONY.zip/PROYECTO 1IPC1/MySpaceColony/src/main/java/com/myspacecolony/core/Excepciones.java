package com.myspacecolony.core;


public class Excepciones {
public static class InvalidActionException extends Exception{
public InvalidActionException(String m){ super(m);} }


public static class NotEnoughCreditsException extends Exception{
public NotEnoughCreditsException(){ super("Créditos insuficientes"); }
}
}