package com.myspacecolony.ui;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.myspacecolony.core.Celda;
import com.myspacecolony.core.Excepciones.NotEnoughCreditsException;
import com.myspacecolony.core.Parcera;
import com.myspacecolony.core.DatosMision;
import com.myspacecolony.core.InicioMision;
import com.myspacecolony.core.Sonido;
import com.myspacecolony.core.TipoSuelo;
import com.myspacecolony.farming.Manzanero;
import com.myspacecolony.farming.Cultivo;
import com.myspacecolony.farming.Maiz;
import com.myspacecolony.industry.Extractor;
import com.myspacecolony.items.Productos;
import com.myspacecolony.market.Tienda;
import com.myspacecolony.ranch.GallinaAlienigena;
import com.myspacecolony.ranch.VacaCosmica;
import com.myspacecolony.ranch.ManejoParcela;

public class ActionsPanel extends JPanel {
    private final DatosMision mission; private final MapPanel map;

    public ActionsPanel(DatosMision m, MapPanel map){
        this.mission=m; this.map=map;
        setLayout(new GridLayout(0,1,8,8));

        // Agricultura
        JButton buyMaize = new JButton("Comprar semillas Maíz (10/celda)");
        JButton buyApple = new JButton("Comprar semillas Manzano (15/celda)");
        JButton plantMaize = new JButton("Sembrar Maíz en celda");
        JButton plantApple = new JButton("Sembrar Manzano en celda");
        JButton installEx = new JButton("Instalar extractor (120)");
        JButton harvest = new JButton("Cosecha (FIFO)");
        JButton clean = new JButton("Limpiar celda (20)");
        JButton cleanAll = new JButton("Limpiar TODO (20/u)");

        // Mercado comida criaturas
        JButton buyHerbFood = new JButton("Comprar alimento herbívoro (x10)");
        JButton buyOmniFood = new JButton("Comprar alimento omnívoro (x10)");

        // NUEVO: Fertilizantes
        JButton buyFertA = new JButton("Comprar Fert A (+20%)");
        JButton buyFertB = new JButton("Comprar Fert B (+35%)");
        JButton buyFertC = new JButton("Comprar Fert C (+50%)");
        JButton applyFert = new JButton("Aplicar fertilizante a celda fértil");

        // Parcelas & crianza
        JButton createParcel = new JButton("Crear parcela (tamaño N)");
        JButton delParcel = new JButton("Eliminar parcela vacía (10)");
        JButton buyCow = new JButton("Comprar Vaca cósmica (60)");
        JButton buyChicken = new JButton("Comprar Gallina alienígena (20)");
        JButton collect = new JButton("Recolectar continua (parcela)");
        JButton slaughter = new JButton("Destazar todo (parcela)");
        JButton cleanCorpses = new JButton("Limpiar cadáveres parcela (10 c/u)");

        // Reportes
        JButton exportCrops = new JButton("Reporte Cultivos (HTML)");
        JButton exportCreatures = new JButton("Reporte Criaturas (HTML)");
        JButton exportSummary = new JButton("Reporte Resumen (HTML)");

        // Orden en panel
        add(buyMaize); add(buyApple); add(plantMaize); add(plantApple);
        add(installEx); add(harvest); add(clean); add(cleanAll);
        add(buyHerbFood); add(buyOmniFood);
        add(buyFertA); add(buyFertB); add(buyFertC); add(applyFert);
        add(createParcel); add(delParcel);
        add(buyCow); add(buyChicken);
        add(collect); add(slaughter); add(cleanCorpses);
        add(exportCrops); add(exportCreatures); add(exportSummary);

        // Listas
        buyMaize.addActionListener(e -> venderSemillas(true));
        buyApple.addActionListener(e -> venderSemillas(false));
        plantMaize.addActionListener(e -> plantar(true));
        plantApple.addActionListener(e -> plantar(false));
        installEx.addActionListener(e -> instalarExtractor());
        harvest.addActionListener(e -> cosecharFIFO());
        clean.addActionListener(e -> limpiarCelda());
        cleanAll.addActionListener(e -> limpiarCeldas());
        buyHerbFood.addActionListener(e -> buyHerb());
        buyOmniFood.addActionListener(e -> buyOmni());
        buyFertA.addActionListener(e -> buyFert(Tienda.FERT_A));
        buyFertB.addActionListener(e -> buyFert(Tienda.FERT_B));
        buyFertC.addActionListener(e -> buyFert(Tienda.FERT_C));
        applyFert.addActionListener(e -> applyFert());
        createParcel.addActionListener(e -> crearParcela());
        delParcel.addActionListener(e -> eliminarParcela());
        buyCow.addActionListener(e -> buyCriatura(true));
        buyChicken.addActionListener(e -> buyCriatura(false));
        collect.addActionListener(e -> colectarParcela());
        slaughter.addActionListener(e -> matarParcela());
        cleanCorpses.addActionListener(e -> limpiarMuertos());
        exportCrops.addActionListener(e -> exportarCultivos());
        exportCreatures.addActionListener(e -> exportarCriaturas());
        exportSummary.addActionListener(e -> exportarResumen());
    }

    // ===== Agricultura =====
    //Comprar semillas
    private void venderSemillas(boolean maize){
        String s = JOptionPane.showInputDialog(this,"¿Cuántas celdas sembrarás?","1");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            if(maize) Tienda.buyMaizeSeeds(mission,n); else Tienda.buyAppleSeeds(mission,n);
            JOptionPane.showMessageDialog(this,"Semillas compradas");
        }catch(NotEnoughCreditsException ex){ msg(ex.getMessage()); }
    }
    private void plantar(boolean maize){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda fértil"); return; }
        try{
            Productos out = maize? Tienda.COMIDA_GRAIN : Tienda.COMIDA_FRUIT;
            Cultivo crop = maize? new Maiz(out) : new Manzanero(out);
            mission.getGrid().lugarCultivo(r,c,crop);
            mission.getStats().fertilizanteCeldas++;
            if(maize) mission.getStats().maizCeldas++;
            else      mission.getStats().manzanaCeldas++;
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void instalarExtractor(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una acuífera"); return; }
        try{
            mission.spendCredits(120);
            mission.getGrid().lugarExtractor(r,c,new Extractor());
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void cosecharFIFO(){
    if(mission.isHarvesting()){ Sonido.error(); msg("Ya hay cosecha en curso"); return; }
    if(mission.harvestQueueSize()==0){ Sonido.error(); msg("No hay cultivos listos en cola"); return; }
    mission.beginNextHarvest();
    Sonido.completado();
    msg("¡Cosecha iniciada (FIFO)!");
}

    private void limpiarCelda(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda"); return; }
        try{ mission.spendCredits(20); mission.getGrid().limpiarCeldas(r,c); }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void limpiarCeldas(){
        Parcera g=mission.getGrid(); int rows=g.getFila(), cols=g.getColumna();
        int cnt=0; for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) cnt++;
        if(cnt==0){ msg("No hay celdas arruinadas"); return; }
        int total=cnt*20; int ok=JOptionPane.showConfirmDialog(this,"Se limpiarán "+cnt+" celdas por "+total+" créditos. ¿Confirmar?","Limpiar TODO",JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{ mission.spendCredits(total); for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) g.get(r,c).clearAll(); }catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== Mercado comida criaturas =====
    private void buyHerb(){
        try{ Tienda.buyHerbFood(mission,10); msg("Compraste 10 de alimento herbívoro"); }
        catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void buyOmni(){
        try{ Tienda.buyOmniFood(mission,10); msg("Compraste 10 de alimento omnívoro"); }
        catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== NUEVO: Fertilizantes =====
    private void buyFert(Productos fert){
        String s = JOptionPane.showInputDialog(this,"¿Cuántas unidades comprar?","1");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            if(fert==Tienda.FERT_A) Tienda.buyFertA(mission,n);
            else if(fert==Tienda.FERT_B) Tienda.buyFertB(mission,n);
            else Tienda.buyFertC(mission,n);
            msg("Compraste "+n+" de "+fert.name);
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void applyFert(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda fértil"); return; }
        Celda cl = mission.getGrid().get(r,c);
        if(cl.getTerrain()!=TipoSuelo.FERTIL){ msg("Solo en terreno fértil"); return; }

        String[] opts = { Tienda.FERT_A.name, Tienda.FERT_B.name, Tienda.FERT_C.name };
        int sel = JOptionPane.showOptionDialog(this, "¿Qué fertilizante aplicar?",
                "Aplicar fertilizante", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opts, opts[0]);
        if(sel<0) return;

        Productos p = (sel==0? Tienda.FERT_A : sel==1? Tienda.FERT_B : Tienda.FERT_C);
        if(!mission.getInventory().consume(p,1)){ msg("No tienes "+p.name+" en bodega"); return; }
        double boost = Tienda.fertilizerBoost(p);
        cl.applyFertilizer(boost);
        msg("Aplicado "+p.name+". Fertilidad ahora: x" + String.format("%.2f", cl.getFertility()));
    }

    // ===== Parcelas & crianza =====
    private void crearParcela(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona celda fértil de inicio"); return; }
        String s = JOptionPane.showInputDialog(this,"Tamaño de parcela (número de celdas fértiles contiguas):","2");
        if(s==null) return; int n=Integer.parseInt(s);
        try{
            ManejoParcela p = mission.getGrid().crearParcelaDe(r,c,n);
            msg("Parcela creada con id="+p.id+" y capacidad="+p.cells.size());
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void eliminarParcela(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda de la parcela"); return; }
        try{
            mission.spendCredits(10);
            mission.getGrid().eliminarParcelaSiNA(r,c);
            msg("Parcela eliminada");
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void buyCriatura(boolean cow){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una celda de la parcela"); return; }
        ManejoParcela p = mission.getGrid().getParceladeCelda(r,c);
        if(p==null){ msg("Aquí no hay parcela"); return; }
        try{
            if(cow){ mission.spendCredits(Tienda.COW_PRICE); if(!p.addCriatura(new VacaCosmica())){ msg("Sin espacio o especie incompatible"); mission.addCredits(Tienda.COW_PRICE); return; } mission.getStats().vacasCompradas++; }
            else   { mission.spendCredits(Tienda.CHICK_PRICE); if(!p.addCriatura(new GallinaAlienigena())){ msg("Sin espacio o especie incompatible"); mission.addCredits(Tienda.CHICK_PRICE); return; } mission.getStats().gallinaCompradas++; }
            msg("Agregado a la parcela");
        }catch(Exception ex){ msg(ex.getMessage()); }
    }
    private void colectarParcela(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        ManejoParcela p = mission.getGrid().getParceladeCelda(r,c); if(p==null){ msg("No hay parcela"); return; }
        int got = p.colectarTodo(mission);
        msg("Recolectado: "+got+" unidades");
    }
    private void matarParcela(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        ManejoParcela p = mission.getGrid().getParceladeCelda(r,c); if(p==null){ msg("No hay parcela"); return; }
        int before = mission.getStats().vacaSacrificada + mission.getStats().gallinaSacrificada;
        int n = p.matarTodos(mission);
        int after = mission.getStats().vacaSacrificada + mission.getStats().gallinaSacrificada;
        int delta = after - before;
        if(n>0){ mission.getStats().sacrificios += n; msg("Destazados: "+delta); }
        else msg("Nada para destazar");
    }
    private void limpiarMuertos(){
        int r=map.getSelR(), c=map.getSelC(); if(r<0){ msg("Selecciona una parcela"); return; }
        ManejoParcela p = mission.getGrid().getParceladeCelda(r,c); if(p==null){ msg("No hay parcela"); return; }
        int corps = p.corpses();
        if(corps==0){ msg("No hay cadáveres"); return; }
        int cost = corps * 10;
        int ok = JOptionPane.showConfirmDialog(this,"Se limpiarán "+corps+" cadáver(es) por "+cost+" créditos. ¿Confirmar?","Limpieza",JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{ mission.spendCredits(cost); p.limpiarMuertos(); msg("Parcela limpia"); }catch(Exception ex){ msg(ex.getMessage()); }
    }

    // ===== Reportes =====
    private void exportarCultivos(){
        java.io.File html = elegirFile("reporte_cultivos.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            InicioMision s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Cultivos</title>");
            pw.println("<h1>Reporte de Cultivos</h1>");
            pw.println("<table border=1 cellpadding=6>");
            pw.println("<tr><th>Concepto</th><th>Maíz (grano)</th><th>Manzano (fruta)</th><th>Total</th></tr>");
            pw.printf("<tr><td>Semillas compradas</td><td>%d</td><td>%d</td><td>%d</td></tr>",
                    s.semillasMaizComprado, s.semillasManzanaComprado, s.semillasMaizComprado+s.semillasManzanaComprado);
            pw.printf("<tr><td>Celdas sembradas</td><td>%d</td><td>%d</td><td>%d</td></tr>",
                    s.maizCeldas, s.manzanaCeldas, s.fertilizanteCeldas);
            pw.printf("<tr><td>Alimento producido</td><td>%d (grano)</td><td>%d (fruta)</td><td>%d</td></tr>",
                    s.granoProducido, s.frutaProducida, s.totalComidaProducida);
            pw.println("</table>");
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    private void exportarCriaturas(){
        java.io.File html = elegirFile("reporte_criaturas.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            InicioMision s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Criaturas</title>");
            pw.println("<h1>Reporte de Criaturas</h1>");
            pw.println("<table border=1 cellpadding=6>");
            pw.println("<tr><th>Especie</th><th>Crías compradas</th><th>Destazadas</th><th>Producción continua</th><th>Materias/Alimentos por destace</th></tr>");
            pw.printf("<tr><td>Vaca cósmica</td><td>%d</td><td>%d</td><td>%d leche</td><td>%d cuero, %d carne</td></tr>",
                    s.vacasCompradas, s.vacaSacrificada, s.lecheProducida, s.cueroProducido, s.carneVacaProducida);
            pw.printf("<tr><td>Gallina alienígena</td><td>%d</td><td>%d</td><td>%d huevos</td><td>%d carne</td></tr>",
                    s.gallinaCompradas, s.gallinaSacrificada, s.huevoProducida, s.polloGallinaProducida);
            pw.println("</table>");
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    private void exportarResumen(){
        java.io.File html = elegirFile("reporte_resumen.html"); if(html==null) return;
        try(java.io.PrintWriter pw = new java.io.PrintWriter(html, java.nio.charset.StandardCharsets.UTF_8)){
            long dur = mission.getDurationMs()/1000;
            InicioMision s = mission.getStats();
            pw.println("<!doctype html><meta charset='utf-8'><title>Reporte Resumen</title>");
            pw.printf("<h1>Resumen de misión</h1><p>Duración: %ds — Créditos actuales: %d — Salud: %d%%</p>",
                    dur, mission.getCredits(), mission.getCrewHealth());
            pw.println("<h2>Totales</h2>");
            pw.printf("<p>Alimento producido: %d | Consumido por tripulación: %d | Celdas sembradas: %d</p>",
                    s.totalComidaProducida, s.totalComidaProducidaVaca, s.fertilizanteCeldas);
        }catch(Exception ex){ msg("Error al exportar: "+ex.getMessage()); }
    }

    // ===== util =====
    private java.io.File elegirFile(String def){
        javax.swing.JFileChooser ch = new javax.swing.JFileChooser();
        ch.setSelectedFile(new java.io.File(def));
        int r=ch.showSaveDialog(this);
        return r==javax.swing.JFileChooser.APPROVE_OPTION? ch.getSelectedFile(): null;
    }
    private void msg(String s){ JOptionPane.showMessageDialog(this,s); }
}
