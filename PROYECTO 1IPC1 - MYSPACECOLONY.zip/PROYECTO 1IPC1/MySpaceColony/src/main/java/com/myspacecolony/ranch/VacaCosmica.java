package com.myspacecolony.ranch;

import com.myspacecolony.market.Tienda;

public class VacaCosmica extends Criatura  {
    public VacaCosmica(){
        super("Vaca cósmica", Especie.HERBIVORO, 2.0);
        this.contProducto = Tienda.LECHE; this.contBase = 3;
        this.killA = Tienda.CUERO; this.killAPercent = 25;
        this.killB = Tienda.CARNE_VACA; this.killBPercent = 75;
    }
}
