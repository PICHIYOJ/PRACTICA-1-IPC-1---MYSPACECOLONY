package com.myspacecolony.ui;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;

import com.myspacecolony.core.RelojJuego;
import com.myspacecolony.core.Parcera;
import com.myspacecolony.core.DatosMision;
import com.myspacecolony.core.GuardadoMaestro;
import com.myspacecolony.core.Sonido;

public class MainWindow extends JFrame {
    private final DatosMision mission;
    private final HUDPanel hud;
    private final MapPanel map;
    private final ActionsPanel actions;
    private RelojJuego clock;

    public MainWindow(DatosMision mission) {
        super();
        this.mission = mission;
        setTitle("MySpaceColony — Cmdr " + mission.getCommanderName() + " (" + mission.getNick() + ")");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 680);
        setLocationRelativeTo(null);

        // Menú
        setJMenuBar(buildMenu());

        hud = new HUDPanel(mission);
        map = new MapPanel(mission);
        actions = new ActionsPanel(mission, map);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(map), actions);
        split.setDividerLocation(640);
        split.setResizeWeight(1.0);

        setLayout(new BorderLayout());
        add(hud, BorderLayout.NORTH);
        add(split, BorderLayout.CENTER);

        mission.attachWindow(this);
        clock = new RelojJuego(mission);
        clock.start();

        // cerrar limpia el clock
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) {
                if(clock!=null) clock.stopClock();
            }
        });
    }

    private JMenuBar buildMenu(){
        JMenuBar bar = new JMenuBar();

        JMenu mPartida = new JMenu("Partida");
        JMenuItem save1 = new JMenuItem("Guardar en Ranura 1");
        JMenuItem save2 = new JMenuItem("Guardar en Ranura 2");
        JMenuItem save3 = new JMenuItem("Guardar en Ranura 3");
        JMenuItem load1 = new JMenuItem("Cargar Ranura 1");
        JMenuItem load2 = new JMenuItem("Cargar Ranura 2");
        JMenuItem load3 = new JMenuItem("Cargar Ranura 3");

        save1.addActionListener(e -> Guardar(0));
        save2.addActionListener(e -> Guardar(1));
        save3.addActionListener(e -> Guardar(2));
        load1.addActionListener(e -> Cargar(0));
        load2.addActionListener(e -> Cargar(1));
        load3.addActionListener(e -> Cargar(2));

        mPartida.add(save1); mPartida.add(save2); mPartida.add(save3);
        mPartida.addSeparator();
        mPartida.add(load1); mPartida.add(load2); mPartida.add(load3);

        JMenu mColonia = new JMenu("Colonia");
        JMenuItem addRow = new JMenuItem("Comprar +1 Fila");
        JMenuItem addCol = new JMenuItem("Comprar +1 Columna");
        addRow.addActionListener(e -> comprarFila());
        addCol.addActionListener(e -> comprarColumna());
        mColonia.add(addRow); mColonia.add(addCol);

        JMenu mLimpieza = new JMenu("Limpieza");
        JMenuItem cleanRuins = new JMenuItem("Limpiar celdas arruinadas (20/u)");
        cleanRuins.addActionListener(e -> limpiarArruinadas());
        mLimpieza.add(cleanRuins);

        JMenu mOpciones = new JMenu("Opciones");
        JCheckBoxMenuItem sound = new JCheckBoxMenuItem("Sonido habilitado", Sonido.enabled);
        sound.addActionListener(e -> Sonido.enabled = sound.isSelected());
        mOpciones.add(sound);

        JMenu mAyuda = new JMenu("Ayuda");
        JMenuItem about = new JMenuItem("Acerca de…");
        about.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "MySpaceColony (demo académica)\nFase 3: guardado en memoria, expansión, limpieza y sonidos.",
                "Acerca de", JOptionPane.INFORMATION_MESSAGE));
        mAyuda.add(about);

        bar.add(mPartida); bar.add(mColonia); bar.add(mLimpieza); bar.add(mOpciones); bar.add(mAyuda);
        return bar;
    }

    private void Guardar(int slot){
        boolean ok = GuardadoMaestro.save(slot, mission);
        if(ok){ Sonido.completado(); JOptionPane.showMessageDialog(this,"Guardado en "+GuardadoMaestro.espaciosName(slot)); }
        else { Sonido.error(); JOptionPane.showMessageDialog(this,"No se pudo guardar","Error",JOptionPane.ERROR_MESSAGE); }
    }
    private void Cargar(int slot){
        DatosMision loaded = GuardadoMaestro.load(slot);
        if(loaded==null){ Sonido.error(); JOptionPane.showMessageDialog(this,"Ranura vacía","Aviso",JOptionPane.WARNING_MESSAGE); return; }
        // abrir nueva ventana con la partida cargada
        Sonido.completado();
        new MainWindow(loaded).setVisible(true);
        if(clock!=null) clock.stopClock();
        dispose();
    }

    //Fila
    private void comprarFila(){
        int cols = mission.getGrid().getColumna();
        int cost = Parcera.EXPANSION_COST_PER_CELL * cols;
        int ok = JOptionPane.showConfirmDialog(this, "Costo: "+cost+" créditos.\n¿Comprar +1 Fila?",
                "Expandir", JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{
            mission.spendCredits(cost);
            mission.getGrid().addFila(1);
            Sonido.completado();
            refreshHUD();
            map.revalidate(); map.repaint();
        }catch(Exception ex){
            Sonido.error();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //Columna
    private void comprarColumna(){
        int rows = mission.getGrid().getFila();
        int cost = Parcera.EXPANSION_COST_PER_CELL * rows;
        int ok = JOptionPane.showConfirmDialog(this, "Costo: "+cost+" créditos.\n¿Comprar +1 Columna?",
                "Expandir", JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{
            mission.spendCredits(cost);
            mission.getGrid().addClumna(1);
            Sonido.completado();
            refreshHUD();
            map.revalidate(); map.repaint();
        }catch(Exception ex){
            Sonido.error();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //Limpieza celdas arruinadas
    private void limpiarArruinadas(){
        Parcera g=mission.getGrid(); int rows=g.getFila(), cols=g.getColumna();
        int cnt=0; for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) cnt++;
        if(cnt==0){ JOptionPane.showMessageDialog(this,"No hay celdas arruinadas"); return; }
        int total=cnt*20;
        int ok = JOptionPane.showConfirmDialog(this,"Se limpiarán "+cnt+" celdas por "+total+" créditos. ¿Confirmar?",
                "Limpieza masiva", JOptionPane.OK_CANCEL_OPTION);
        if(ok!=JOptionPane.OK_OPTION) return;
        try{
            mission.spendCredits(total);
            for(int r=0;r<rows;r++) for(int c=0;c<cols;c++) if(g.get(r,c).isRuined()) g.get(r,c).clearAll();
            Sonido.completado();
            map.repaint();
        }catch(Exception ex){
            Sonido.error();
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Llamado por GameClock */
    public void refreshHUD() {
        hud.refresh();
        map.repaint();
    }
}
