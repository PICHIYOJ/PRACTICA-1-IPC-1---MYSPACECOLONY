package com.myspacecolony.farming;

import com.myspacecolony.items.Productos;

public class Manzanero extends Cultivo {
    private int cyclesLeft = 3; // muere tras varios cortes
    public Manzanero(Productos output){
        super("Manzano alienígena", false, 8000, output, 1500, 2500);
    }
    @Override public int baseYield(){ return 4 + (int)(Math.random()*4); }
    @Override public boolean diesOnHarvest(){ return --cyclesLeft <= 0; }
}
