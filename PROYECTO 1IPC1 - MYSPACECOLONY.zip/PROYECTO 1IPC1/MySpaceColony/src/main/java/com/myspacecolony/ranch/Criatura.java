package com.myspacecolony.ranch;

import com.myspacecolony.core.DatosMision;
import com.myspacecolony.items.Productos;
import com.myspacecolony.market.Tienda;

public abstract class Criatura implements java.io.Serializable {
    protected final String name;
    protected final Especie tipo;
    protected final double espacios; // celdas requeridas (ej: 2.0 vaca, 0.5 gallina)
    protected boolean vivo = true;

    // Auto-alimentación (hasta 5)
    protected final Productos[] prefs = new Productos[5];
    protected int prefN = 0;

    // Estado
    protected long edadMs = 0;          // edad
    protected long hambreMs = 0;       // hambre acumulada
    protected long starveMs = 0;       // tiempo sin comer

    // Producción continua
    protected Productos contProducto = null;
    protected int contBase = 0;  // unidades por recolección

    // Producción por destace (dos productos con porcentajes)
    protected Productos killA = null; protected int killAPercent = 0;
    protected Productos killB = null; protected int killBPercent = 0;

    public Criatura(String name, Especie kind, double space){
        this.name=name; this.tipo=kind; this.espacios=space;
        // defaults de comida
        if(kind==Especie.HERBIVORO){ addPref(Tienda.HERB1); addPref(Tienda.HERB2); addPref(Tienda.HERB3); }
        else { addPref(Tienda.OMNI1); addPref(Tienda.OMNI2); addPref(Tienda.OMNI3); }
    }

    protected void addPref(Productos p){ if(prefN<5) prefs[prefN++] = p; }

    public String getName(){ return name; }
    public boolean isAlive(){ return vivo; }
    public double spaceRequired(){ return espacios; }

    /** Avance del tiempo; intenta comer si tiene hambre */
    public void tick(long dt, DatosMision m){
        if(!vivo) return;
        edadMs += dt;
        hambreMs += dt;

        if(hambreMs >= hungerPeriodMs()){
            // intenta consumir 1 unidad de alguna preferencia
            boolean ate=false;
            for(int i=0;i<prefN;i++){
                if(m.getInventory().consume(prefs[i], 1)){ ate=true; break; }
            }
            if(ate){ hambreMs = 0; starveMs = 0; }
            else { starveMs += hungerPeriodMs(); }
        }

        // muerte por inanición o vejez
        if(starveMs >= maxStarveMs() || edadMs >= maxAgeMs()){
            vivo=false;
            // ocupa espacio hasta limpiar; limpieza la hace la parcela
        }
    }

    /** Recolección continua (leche, huevos). Devuelve unidades producidas */
  public int collect(DatosMision m){
    if(!vivo || contProducto==null) return 0;
    int mult = edadMs < juvenileMs()? 50 : edadMs > elderMs()? 50 : 100;
    int qty = contBase * mult / 100;
    m.getInventory().add(contProducto, qty);
    // === acumular en estadísticas ===
    if(contProducto == Tienda.LECHE) m.getStats().lecheProducida += qty;
    if(contProducto == Tienda.HUEVOS) m.getStats().huevoProducida += qty;
    return qty;
}

public void slaughter(DatosMision m){
    if(!vivo) return;

    int total = killAPercent + killBPercent;
    // Si la especie no tiene porcentajes de destace, igual muere pero no entrega nada.
    if (total <= 0) { 
        vivo = false; 
        return; 
    }

    int base = 10; // producción base de destace (demo)

    if(killAPercent > 0){
        int q = base * killAPercent / 100;
        m.getInventory().add(killA, q);
        if(killA == Tienda.CUERO)         m.getStats().cueroProducido      += q;
        if(killA == Tienda.CARNE_VACA)        m.getStats().carneVacaProducida      += q;
        if(killA == Tienda.CARNE_GALLINA)    m.getStats().polloGallinaProducida  += q;
    }

    if(killBPercent > 0){
        int q = base * killBPercent / 100;
        m.getInventory().add(killB, q);
        if(killB == Tienda.CUERO)         m.getStats().cueroProducido      += q;
        if(killB == Tienda.CARNE_VACA)        m.getStats().carneVacaProducida      += q;
        if(killB == Tienda.CARNE_GALLINA)    m.getStats().polloGallinaProducida  += q;
    }

    if(tipo == Especie.HERBIVORO) m.getStats().vacaSacrificada++;
    else                              m.getStats().gallinaSacrificada++;

    vivo = false;
}



    // parámetros de especie
    protected long hungerPeriodMs(){ return 5_000; }
    protected long maxStarveMs(){ return 30_000; }
    protected long maxAgeMs(){ return 5*60_000; } // 5 minutos demo
    protected long juvenileMs(){ return 30_000; }
    protected long elderMs(){ return 4*60_000; }
}
