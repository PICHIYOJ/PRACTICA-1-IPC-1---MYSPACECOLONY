package com.myspacecolony.core;

import com.myspacecolony.ds.Cola;
import com.myspacecolony.ds.ArregloDinamico;
import com.myspacecolony.ranch.ManejoParcela;

public class Parcera implements java.io.Serializable {
    private Celda[][] cells;
    private int fila, columna;

    private final ArregloDinamico<ManejoParcela> parcels = new ArregloDinamico<>();
    private int nextParcelId = 1;

    public static final int EXPANSION_COST_PER_CELL = 50; // precio por celda nueva

    public Parcera(int fila,int columna){ this.fila=fila; this.columna=columna; cells=new Celda[fila][columna]; generacion(); }

    private void generacion(){
        for(int r=0;r<fila;r++){
            for(int c=0;c<columna;c++){
                cells[r][c] = new Celda(r,c, randomTerreno());
            }
        }
    }

    private TipoSuelo randomTerreno(){
        double p = Math.random();
        return (p<0.40)? TipoSuelo.FERTIL : (p<0.75? TipoSuelo.ACUIFERO : TipoSuelo.ARIDO);
    }

    public int getFila(){ return fila; }
    public int getColumna(){ return columna; }
    public Celda get(int r,int c){ return cells[r][c]; }

    public ArregloDinamico<Celda> allCeldas(){
        ArregloDinamico<Celda> out = new ArregloDinamico<>();
        for(int r=0;r<fila;r++) for(int c=0;c<columna;c++) out.add(cells[r][c]);
        return out;
    }

    // ======= FASE 2: parcelas =======
    public ManejoParcela getParceladeCelda(int r,int c){
        int id = cells[r][c].getParcelId();
        if(id<0) return null;
        for(int i=0;i<parcels.size();i++) if(parcels.get(i).id==id) return parcels.get(i);
        return null;
    }

    public ManejoParcela crearParcelaDe(int sr,int sc,int count) throws com.myspacecolony.core.Excepciones.InvalidActionException {
        if(!in(sr,sc)) throw new com.myspacecolony.core.Excepciones.InvalidActionException("Fuera de rango");
        if(cells[sr][sc].getTerrain()!=TipoSuelo.FERTIL) throw new com.myspacecolony.core.Excepciones.InvalidActionException("Debe iniciar en fértil");
        if(cells[sr][sc].getParcelId()>=0) throw new com.myspacecolony.core.Excepciones.InvalidActionException("Celda ya en parcela");

        ManejoParcela p = new ManejoParcela(nextParcelId++);
        parcels.add(p);
        Cola<int[]> q = new Cola<>();
        q.entrarCola(new int[]{sr,sc});
        int taken=0;
        boolean[][] vis = new boolean[fila][columna];
        while(!q.isEmpty() && taken<count){
            int[] v = q.salirCola();
            int r=v[0], c=v[1];
            if(!in(r,c) || vis[r][c]) continue; vis[r][c]=true;
            Celda cl = cells[r][c];
            if(cl.getTerrain()==TipoSuelo.FERTIL && cl.getParcelId()<0 && cl.getCrop()==null && cl.getExtractor()==null){
                cl.setParcelId(p.id);
                p.cells.add(cl);
                taken++;
            }
            if(in(r-1,c)) q.entrarCola(new int[]{r-1,c});
            if(in(r+1,c)) q.entrarCola(new int[]{r+1,c});
            if(in(r,c-1)) q.entrarCola(new int[]{r,c-1});
            if(in(r,c+1)) q.entrarCola(new int[]{r,c+1});
        }
        if(p.cells.size()==0) throw new com.myspacecolony.core.Excepciones.InvalidActionException("No hay fértiles contiguas libres");
        return p;
    }

    public void eliminarParcelaSiNA(int r,int c) throws com.myspacecolony.core.Excepciones.InvalidActionException {
        ManejoParcela p = getParceladeCelda(r,c);
        if(p==null) throw new com.myspacecolony.core.Excepciones.InvalidActionException("No hay parcela aquí");
        if(!p.sinVida()) throw new com.myspacecolony.core.Excepciones.InvalidActionException("Parcela con seres activos o cadáveres");
        for(int i=0;i<p.cells.size();i++) p.cells.get(i).setParcelId(-1);
        for(int i=0;i<parcels.size();i++) if(parcels.get(i).id==p.id){ parcels.removeAt(i); break; }
    }

    private boolean in(int r,int c){ return r>=0 && r<fila && c>=0 && c<columna; }

    // ==== APIs cultivo/extractor ====
    public void lugarCultivo(int r,int c, com.myspacecolony.farming.Cultivo crop)
            throws com.myspacecolony.core.Excepciones.InvalidActionException {
        Celda cl = cells[r][c];
        if(cl.getTerrain()!=TipoSuelo.FERTIL)
            throw new com.myspacecolony.core.Excepciones.InvalidActionException("Se siembra solo en fértil");
        if(cl.getCrop()!=null || cl.getExtractor()!=null)
            throw new com.myspacecolony.core.Excepciones.InvalidActionException("Celda ocupada");
        crop.setFertilidadExtra(cl.getFertility()); // Fase 2.5
        cl.setCrop(crop);
    }
    public void lugarExtractor(int r,int c, com.myspacecolony.industry.Extractor ex)
            throws com.myspacecolony.core.Excepciones.InvalidActionException {
        Celda cl=cells[r][c];
        if(cl.getTerrain()!=TipoSuelo.ACUIFERO)
            throw new com.myspacecolony.core.Excepciones.InvalidActionException("Extractor solo en acuífero");
        if(cl.getCrop()!=null || cl.getExtractor()!=null)
            throw new com.myspacecolony.core.Excepciones.InvalidActionException("Celda ocupada");
        cl.setExtractor(ex);
    }
    public void limpiarCeldas(int r,int c){ cells[r][c].clearAll(); }

    // ======= FASE 3: Expansión =======
    public void addFila(int addRows){
        if(addRows<=0) return;
        int newRows = fila + addRows;
        Celda[][] newCells = new Celda[newRows][columna];
        for(int r=0;r<fila;r++) for(int c=0;c<columna;c++) newCells[r][c] = cells[r][c];
        // generar filas nuevas al final
        for(int r=fila; r<newRows; r++){
            for(int c=0;c<columna;c++){
                newCells[r][c] = new Celda(r,c, randomTerreno());
            }
        }
        cells = newCells;
        fila = newRows;
    }

    public void addClumna(int addCols){
        if(addCols<=0) return;
        int newCols = columna + addCols;
        Celda[][] newCells = new Celda[fila][newCols];
        for(int r=0;r<fila;r++){
            for(int c=0;c<columna;c++) newCells[r][c] = cells[r][c];
            for(int c=columna;c<newCols;c++){
                newCells[r][c] = new Celda(r,c, randomTerreno());
            }
        }
        cells = newCells;
        columna = newCols;
    }
}
