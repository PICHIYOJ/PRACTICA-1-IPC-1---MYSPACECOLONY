package com.myspacecolony.core;

public class InicioMision implements java.io.Serializable {
    // generales
    public int creditosGenerados;
    public int totalComidaProducida;
    public int totalComidaProducidaVaca;

    // cultivos
    public int semillasMaizComprado, semillasManzanaComprado;
    public int fertilizanteCeldas;   // total
    public int maizCeldas, manzanaCeldas;
    public int granoProducido, frutaProducida;

    // criaturas
    public int vacasCompradas, gallinaCompradas;
    public int vacaSacrificada, gallinaSacrificada;
    public int lecheProducida, huevoProducida;
    public int cueroProducido, carneVacaProducida, polloGallinaProducida;
    public int sacrificios;
}
