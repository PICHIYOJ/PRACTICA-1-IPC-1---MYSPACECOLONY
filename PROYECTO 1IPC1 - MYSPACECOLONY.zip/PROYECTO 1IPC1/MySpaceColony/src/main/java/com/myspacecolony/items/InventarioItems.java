package com.myspacecolony.items;

public class InventarioItems implements java.io.Serializable {
    public final Productos product;
    public int qty;
    public InventarioItems(Productos p, int q){ this.product=p; this.qty=q; }
}
