package com.myspacecolony.ds;


public class Cola<T> implements java.io.Serializable{
private Object[] data=new Object[8];
private int head=0, tail=0, count=0;


public void entrarCola(T v){
if(count==data.length) aumentar();
data[tail]=v; tail=(tail+1)%data.length; count++;
}
@SuppressWarnings("unchecked")
public T salirCola(){
if(count==0) return null;
T v=(T)data[head]; data[head]=null; head=(head+1)%data.length; count--; return v;
}
public boolean isEmpty(){ return count==0; }
public int size(){ return count; }


private void aumentar(){
Object[] nd=new Object[data.length*2];
for(int i=0;i<count;i++) nd[i]=data[(head+i)%data.length];
data=nd; head=0; tail=count;
}
}