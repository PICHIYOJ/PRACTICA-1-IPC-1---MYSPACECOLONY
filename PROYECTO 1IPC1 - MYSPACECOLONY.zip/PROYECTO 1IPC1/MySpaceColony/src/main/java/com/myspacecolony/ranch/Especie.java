package com.myspacecolony.ranch;
public enum Especie { HERBIVORO, OMNIVORO }
