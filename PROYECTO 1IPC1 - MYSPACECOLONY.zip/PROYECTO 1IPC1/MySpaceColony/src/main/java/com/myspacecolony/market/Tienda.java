package com.myspacecolony.market;

import com.myspacecolony.core.Excepciones.NotEnoughCreditsException;
import com.myspacecolony.core.DatosMision;
import com.myspacecolony.items.Productos;

public class Tienda {
    // Productos base
    public static final Productos COMIDA_GRAIN = new Productos("Grano", Productos.Kind.COMIDA);
    public static final Productos COMIDA_FRUIT = new Productos("Fruta", Productos.Kind.COMIDA);

    // Alimentos para criaturas
    public static final Productos HERB1 = new Productos("Forraje básico", Productos.Kind.COMIDA);
    public static final Productos HERB2 = new Productos("Pellets verdes", Productos.Kind.COMIDA);
    public static final Productos HERB3 = new Productos("Suplemento vegetal", Productos.Kind.COMIDA);
    public static final Productos OMNI1 = new Productos("Pienso mixto", Productos.Kind.COMIDA);
    public static final Productos OMNI2 = new Productos("Larvas proteicas", Productos.Kind.COMIDA);
    public static final Productos OMNI3 = new Productos("Pasta energética", Productos.Kind.COMIDA);

    // Producción criaturas
    public static final Productos LECHE = new Productos("Leche cósmica", Productos.Kind.COMIDA);
    public static final Productos HUEVOS = new Productos("Huevos alienígenas", Productos.Kind.COMIDA);
    public static final Productos CARNE_VACA = new Productos("Carne interplanetaria", Productos.Kind.COMIDA);
    public static final Productos CUERO = new Productos("Cuero espacial", Productos.Kind.RAW);
    public static final Productos CARNE_GALLINA = new Productos("Carne alienígena", Productos.Kind.COMIDA);

    // Semillas
    public static final int MAIZE_SEED_PRICE = 10;
    public static final int APPLE_SEED_PRICE = 15;

    // Alimento criaturas (precio por unidad)
    public static final int HERB_PRICE = 3;
    public static final int OMNI_PRICE = 4;

    // Crías
    public static final int COW_PRICE = 60;
    public static final int CHICK_PRICE = 20;

    // === NUEVO: 3 fertilizantes ===
    public static final Productos FERT_A = new Productos("Fert A (+20%)", Productos.Kind.TECNO);
    public static final Productos FERT_B = new Productos("Fert B (+35%)", Productos.Kind.TECNO);
    public static final Productos FERT_C = new Productos("Fert C (+50%)", Productos.Kind.TECNO);
    public static final int PRICE_FERT_A = 12;
    public static final int PRICE_FERT_B = 18;
    public static final int PRICE_FERT_C = 25;
    public static final double BOOST_FERT_A = 0.20;
    public static final double BOOST_FERT_B = 0.35;
    public static final double BOOST_FERT_C = 0.50;

    public static double fertilizerBoost(Productos p){
        if(p==FERT_A) return BOOST_FERT_A;
        if(p==FERT_B) return BOOST_FERT_B;
        if(p==FERT_C) return BOOST_FERT_C;
        return 0.0;
    }

    // ===== Compras =====
    public static void buyMaizeSeeds(DatosMision m, int cells) throws NotEnoughCreditsException {
        m.spendCredits(cells * MAIZE_SEED_PRICE);
        m.getStats().semillasMaizComprado += cells;
    }
    public static void buyAppleSeeds(DatosMision m, int cells) throws NotEnoughCreditsException {
        m.spendCredits(cells * APPLE_SEED_PRICE);
        m.getStats().semillasManzanaComprado += cells;
    }

    public static void buyHerbFood(DatosMision m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * HERB_PRICE);
        m.getInventory().add(HERB1, units);
    }
    public static void buyOmniFood(DatosMision m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * OMNI_PRICE);
        m.getInventory().add(OMNI1, units);
    }

    public static void buyFertA(DatosMision m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_A);
        m.getInventory().add(FERT_A, units);
    }
    public static void buyFertB(DatosMision m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_B);
        m.getInventory().add(FERT_B, units);
    }
    public static void buyFertC(DatosMision m, int units) throws NotEnoughCreditsException {
        m.spendCredits(units * PRICE_FERT_C);
        m.getInventory().add(FERT_C, units);
    }
}
