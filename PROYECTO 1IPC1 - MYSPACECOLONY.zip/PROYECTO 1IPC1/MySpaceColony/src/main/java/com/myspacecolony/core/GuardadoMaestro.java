package com.myspacecolony.core;

public class GuardadoMaestro {
    // 3 ranuras en memoria
    private static byte[][] espacios = new byte[3][];
    private static String[] nombreGuardado = new String[]{"Ranura 1","Ranura 2","Ranura 3"};

    public static boolean save(int slotIndex, DatosMision m){
        if(slotIndex<0 || slotIndex>=espacios.length) return false;
        // quitar referencias UI antes de serializar
        m.attachWindow(null);
        espacios[slotIndex] = Serializacion.aBytes(m);
        return true;
    }

    public static DatosMision load(int slotIndex){
        if(slotIndex<0 || slotIndex>=espacios.length) return null;
        if(espacios[slotIndex]==null) return null;
        return Serializacion.deBytes(espacios[slotIndex], DatosMision.class);
    }

    public static String espaciosName(int i){ return nombreGuardado[i]; }
    public static boolean hasData(int i){ return espacios[i]!=null; }
}
