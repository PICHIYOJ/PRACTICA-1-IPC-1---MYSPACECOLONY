package com.myspacecolony.ranch;

import com.myspacecolony.market.Tienda;

public class GallinaAlienigena extends Criatura {
    public GallinaAlienigena(){
        super("Gallina alienígena", Especie.OMNIVORO, 0.5);
        this.contProducto = Tienda.HUEVOS; this.contBase = 2;
        this.killA = Tienda.CARNE_GALLINA; this.killAPercent = 100;
    }
}
