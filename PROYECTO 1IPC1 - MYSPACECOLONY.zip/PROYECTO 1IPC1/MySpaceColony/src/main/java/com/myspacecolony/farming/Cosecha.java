package com.myspacecolony.farming;


import com.myspacecolony.core.DatosMision;


public interface Cosecha {
boolean isReady();
void harvest(DatosMision mission);
}