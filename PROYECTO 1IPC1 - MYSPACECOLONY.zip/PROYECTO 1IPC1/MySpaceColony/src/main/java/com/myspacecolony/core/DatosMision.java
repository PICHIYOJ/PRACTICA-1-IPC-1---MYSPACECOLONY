package com.myspacecolony.core;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Optional;

import com.myspacecolony.ds.Cola;
import com.myspacecolony.farming.Cultivo;
import com.myspacecolony.items.Inventario;
import com.myspacecolony.ui.MainWindow;

public class DatosMision implements java.io.Serializable{
    private final String commanderName;
    private final String nick;
    private final long startTime;

    private int vacaVida;     // vida de tripulación
    private int credits;        // créditos

    private final Parcera grid;
    private transient com.myspacecolony.ui.MainWindow window; // referencia UI (no serializar)

    private final InicioMision stats = new InicioMision();
    private final com.myspacecolony.items.Inventario inventory = new Inventario();

    // bitácora binaria simple
    private final File binLog = new File("mission_log.bin");

    // ===== FASE 2: Cola de cosecha (FIFO) =====
    private final Cola<Celda> harvestQueue = new Cola<>();
    private boolean harvesting = false;
    private Celda harvestingCell = null;
    private long harvestRemainingMs = 0;

    private DatosMision(String name,String nick,int credits,int health){
        this.commanderName=name; this.nick=nick; this.credits=credits; this.vacaVida=health;
        this.startTime=System.currentTimeMillis();
        this.grid=new Parcera(5,5);
    }

    public static DatosMision createDefault(String name,String nick){
        return new DatosMision(name,nick, 500, 100);
    }

    // ===== getters básicos =====
    public String getCommanderName(){ return commanderName; }
    public String getNick(){ return nick; }
    public Parcera getGrid(){ return grid; }
    public Inventario getInventory(){ return inventory; }
    public InicioMision getStats(){ return stats; }
    public long getDurationMs(){ return System.currentTimeMillis()-startTime; }

    public int getCredits(){ return credits; }
    public void addCredits(int amt){ credits+=amt; }
    public void spendCredits(int amt) throws com.myspacecolony.core.Excepciones.NotEnoughCreditsException {
        if(credits<amt) throw new com.myspacecolony.core.Excepciones.NotEnoughCreditsException();
        credits-=amt;
    }

    public int getCrewHealth(){ return vacaVida; }
    public void decCrewHealth(int d){ vacaVida=Math.max(0, vacaVida-d); }
    public void addCrewHealth(int d){ vacaVida=Math.min(100, vacaVida+d); }

    public void attachWindow(MainWindow w){ this.window=w; }
    public Optional<MainWindow> getWindowRef(){ return Optional.ofNullable(window); }

    // ===== Cola de cosecha API =====
    public void enqueueReady(Celda cell){
        if(cell==null) return;
        Cultivo c = cell.getCrop();
        if(c!=null && c.isReady() && !c.isQueued()){
            harvestQueue.entrarCola(cell);
            c.setQueued(true);
        }
    }
    public int harvestQueueSize(){ return harvestQueue.size(); }
    public boolean isHarvesting(){ return harvesting; }
    public long getHarvestRemainingMs(){ return harvestRemainingMs; }

    /** Lanza la siguiente cosecha si hay en cola */
    public void beginNextHarvest(){
        if(harvesting || harvestQueue.isEmpty()) return;
        harvestingCell = harvestQueue.salirCola();
        if(harvestingCell==null) return;
        Cultivo crop = harvestingCell.getCrop();
        if(crop==null) return;
        harvesting = true;
        harvestRemainingMs = crop.harvestDurationMs();
    }

    /** Avanza el temporizador de la cosecha en curso; cuando termina, cosecha realmente */
    public void tickHarvest(long dt){
    if(!harvesting) return;
    harvestRemainingMs -= dt;
    if(harvestRemainingMs <= 0){
        com.myspacecolony.farming.Cultivo crop = harvestingCell.getCrop();
        if(crop != null){
            crop.harvest(this);
            if(crop.diesOnHarvest()) harvestingCell.clearAll();
        }
        harvesting = false;
        harvestingCell = null;
        harvestRemainingMs = 0;

        // Sonido de fin de cosecha:
        Sonido.evento();
    }
}

    // ===== Bin log =====
    public void writeBinEvent(int code, int value){
        try(DataOutputStream out = new DataOutputStream(new FileOutputStream(binLog,true))){
            out.writeLong(System.currentTimeMillis());
            out.writeInt(code);
            out.writeInt(value);
        }catch(IOException ignored){}
    }
}
