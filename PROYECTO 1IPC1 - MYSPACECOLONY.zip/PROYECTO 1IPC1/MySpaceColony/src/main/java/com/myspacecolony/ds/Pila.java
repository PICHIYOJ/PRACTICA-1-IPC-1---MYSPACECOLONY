package com.myspacecolony.ds;


public class Pila<T> implements java.io.Serializable {
private Object[] data=new Object[8];
private int top=-1;
public void push(T v){ if(top+1==data.length) grow(); data[++top]=v; }
@SuppressWarnings("unchecked")
public T pop(){ if(top<0) return null; T v=(T)data[top]; data[top--]=null; return v; }
@SuppressWarnings("unchecked")
public T peek(){ return top<0?null:(T)data[top]; }
public boolean isEmpty(){ return top<0; }
private void grow(){ Object[] nd=new Object[data.length*2]; System.arraycopy(data,0,nd,0,data.length); data=nd; }
}