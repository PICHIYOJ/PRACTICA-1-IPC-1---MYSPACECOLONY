package com.myspacecolony.items;

public class Productos implements java.io.Serializable {
    public enum Kind { COMIDA, RAW, TECNO }
    public final String name;
    public final Kind kind;

    public Productos(String name, Kind kind){
        this.name = name; this.kind = kind;
    }

    @Override public String toString(){ return name; }
}
