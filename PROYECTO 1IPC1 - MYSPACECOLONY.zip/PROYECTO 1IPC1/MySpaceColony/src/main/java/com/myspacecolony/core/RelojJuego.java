package com.myspacecolony.core;

import com.myspacecolony.ds.ArregloDinamico;
import com.myspacecolony.farming.Cultivo;
import com.myspacecolony.industry.Extractor;
import com.myspacecolony.ranch.ManejoParcela;

public class RelojJuego extends Thread {
    private final DatosMision mission;
    private volatile boolean running=true;

    public RelojJuego(DatosMision mission){
        this.mission=mission;
        setName("GameClock");
        setDaemon(true);
    }

    @Override
    public void run(){
        long last = System.currentTimeMillis();
        long healthTick=0; // cada 10s baja 1 punto
        while(running){
            try{ Thread.sleep(200); }catch(InterruptedException ignored){}
            long now=System.currentTimeMillis();
            long dt=now-last; last=now; healthTick+=dt;

            // avanzar cultivos, encolar los que acaban de madurar, y extractores
            ArregloDinamico<Celda> cells = mission.getGrid().allCeldas();
            for(int i=0;i<cells.size();i++){
                Celda cell=cells.get(i);
                Cultivo crop=cell.getCrop();
                if(crop!=null){
                    boolean wasReady = crop.isReady();
                    crop.update(dt, mission);
                    if(!wasReady && crop.isReady() && !crop.isQueued()){
                        mission.enqueueReady(cell); // entra a la cola en el orden de maduración
                    }
                }
                Extractor ex=cell.getExtractor();
                if(ex!=null){ ex.actualizar(dt, mission); }
            }
            // ... dentro del bucle run(), después de actualizar cultivos y extractores:
for(int i=0;i<cells.size();i++){
    Celda cell=cells.get(i);
    if(cell.getParcelId()>=0){
        ManejoParcela p = mission.getGrid().getParceladeCelda(cell.fila, cell.columna);
        if(p!=null){ p.tick(dt, mission); }
    }
}

            // procesar cosecha FIFO (una a la vez)
            if(!mission.isHarvesting() && mission.harvestQueueSize()>0){
                mission.beginNextHarvest();
            }
            mission.tickHarvest(dt);

            // vida de la tripulación desciende cada 10s
            if(healthTick>=10_000){
                mission.decCrewHealth(1);
                healthTick=0;
            }

            mission.getWindowRef().ifPresent(w -> w.refreshHUD());
        }
    }

    public void stopClock(){ running=false; }
}
