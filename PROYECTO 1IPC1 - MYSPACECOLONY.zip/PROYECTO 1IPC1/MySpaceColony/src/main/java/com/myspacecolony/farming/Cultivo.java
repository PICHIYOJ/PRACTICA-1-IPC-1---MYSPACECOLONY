package com.myspacecolony.farming;

import com.myspacecolony.core.DatosMision;
import com.myspacecolony.items.Productos;

public abstract class Cultivo implements Cosecha {
    protected final String name;
    protected final boolean grain;             // true=grano, false=fruta
    protected long aumentarTimeMs;
    protected long plantar;
    protected boolean listo = false;
    protected boolean enCola = false;
    protected Productos output;

    // cosecha
    protected long harvestMinMs;
    protected long harvestMaxMs;

    // NUEVO: factor de fertilidad de la celda [0.5 .. 2.0]
    protected double fertilityFactor = 1.0;
    public void setFertilidadExtra(double f){ fertilityFactor = Math.max(0.5, Math.min(2.0, f)); }

    public Cultivo(String name, boolean grain, long growTimeMs, Productos output,
                long harvestMinMs, long harvestMaxMs) {
        this.name = name; this.grain = grain; this.aumentarTimeMs = growTimeMs;
        this.output = output;
        this.harvestMinMs = harvestMinMs; this.harvestMaxMs = harvestMaxMs;
        this.plantar = System.currentTimeMillis();
    }

    public String getName() { return name; }
    public boolean isGrain() { return grain; }

    public void update(long dt, DatosMision mission){
        if(!listo){
            if(System.currentTimeMillis() - plantar >= aumentarTimeMs) listo = true;
        }
    }

    public boolean isReady(){ return listo; }
    public boolean isQueued(){ return enCola; }
    public void setQueued(boolean q){ enCola = q; }

    public long harvestDurationMs(){
        if(harvestMaxMs <= harvestMinMs) return harvestMinMs;
        return harvestMinMs + (long)(Math.random() * (harvestMaxMs - harvestMinMs));
    }

    public abstract int baseYield();
    public abstract boolean diesOnHarvest();

    public void harvest(DatosMision mission){
        if(!listo) return;
        // rendimiento multiplicado por fertilidad
        int qty = (int)Math.max(1, Math.round(baseYield() * fertilityFactor));
        mission.getInventory().add(output, qty);
        mission.getStats().totalComidaProducida += qty;
        if (grain) mission.getStats().granoProducido += qty;
        else       mission.getStats().frutaProducida += qty;

        listo = false;
        enCola = false;

        if(!diesOnHarvest()){
            long var = (long)(aumentarTimeMs * 0.15);
            long newTime = aumentarTimeMs + (long)((Math.random()*2 - 1) * var);
            plantar = System.currentTimeMillis();
            aumentarTimeMs = Math.max(2000, newTime);
        }
    }
}
