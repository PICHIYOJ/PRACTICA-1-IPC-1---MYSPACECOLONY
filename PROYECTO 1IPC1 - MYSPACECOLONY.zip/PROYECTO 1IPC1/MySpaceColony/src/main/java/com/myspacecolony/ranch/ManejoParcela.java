package com.myspacecolony.ranch;

import com.myspacecolony.core.Celda;
import com.myspacecolony.core.DatosMision;
import com.myspacecolony.ds.ArregloDinamico;

public class ManejoParcela implements java.io.Serializable{
    public final int id;
    public final ArregloDinamico<Celda> cells = new ArregloDinamico<>();
    private final ArregloDinamico<Criatura> creatures = new ArregloDinamico<>();
    private Especie kind = null;
    private double used = 0.0;
    private int muertos = 0;

    public ManejoParcela(int id){ this.id = id; }

    public double capacidad(){ return cells.size(); } // 1 celda = 1.0 unidad
    public double free(){ return capacidad() - used; }

    public boolean addCriatura(Criatura c){
        if(!c.isAlive()) return false;
        if(kind==null) kind = (c instanceof GallinaAlienigena)? Especie.OMNIVORO : Especie.HERBIVORO;
        if(kind!=((c instanceof GallinaAlienigena)? Especie.OMNIVORO : Especie.HERBIVORO)) return false;
        if(free() < c.spaceRequired()) return false;
        creatures.add(c);
        used += c.spaceRequired();
        return true;
    }

    public int colectarTodo(DatosMision m){
        int sum=0;
        for(int i=0;i<creatures.size();i++){
            Criatura cr = creatures.get(i);
            sum += cr.collect(m);
        }
        return sum;
    }

    public int matarTodos(DatosMision m){
        int cnt=0;
        for(int i=0;i<creatures.size();i++){
            Criatura cr = creatures.get(i);
            if(cr.isAlive()){ cr.slaughter(m); cnt++; muertos++; used -= 0; /* ocupa hasta limpiar */ }
        }
        return cnt;
    }

    public void tick(long dt, DatosMision m){
        for(int i=0;i<creatures.size();i++){
            Criatura cr = creatures.get(i);
            boolean wasAlive = cr.isAlive();
            cr.tick(dt,m);
            if(wasAlive && !cr.isAlive()){ muertos++; }
        }
    }

    public boolean sinVida(){
        for(int i=0;i<creatures.size();i++) if(creatures.get(i).isAlive()) return false;
        return muertos==0;
    }

    public int corpses(){ return muertos; }
    public void limpiarMuertos(){ muertos = 0; }
}
